import { useState, useEffect, useCallback } from 'react';
import { Message } from '../types';

interface UseInfiniteScrollProps {
  messages: Message[];
  scrollContainerRef: React.RefObject<HTMLDivElement>;
  itemsPerPage?: number;
}

export const useInfiniteScroll = ({ 
  messages, 
  scrollContainerRef, 
  itemsPerPage = 20 
}: UseInfiniteScrollProps) => {
  const [displayedMessages, setDisplayedMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  // Initialize displayed messages
  useEffect(() => {
    if (messages.length === 0) {
      setDisplayedMessages([]);
      setHasMore(false);
      setCurrentPage(1);
      return;
    }

    const totalPages = Math.ceil(messages.length / itemsPerPage);
    const startIndex = Math.max(0, messages.length - itemsPerPage);
    const initialMessages = messages.slice(startIndex);
    
    setDisplayedMessages(initialMessages);
    setHasMore(totalPages > 1);
    setCurrentPage(1);
  }, [messages.length, itemsPerPage]);

  // Update displayed messages when new messages are added
  useEffect(() => {
    if (messages.length > 0) {
      const totalPages = Math.ceil(messages.length / itemsPerPage);
      const messagesToShow = currentPage * itemsPerPage;
      const startIndex = Math.max(0, messages.length - messagesToShow);
      const newDisplayedMessages = messages.slice(startIndex);
      
      setDisplayedMessages(newDisplayedMessages);
      setHasMore(currentPage < totalPages);
    }
  }, [messages, currentPage, itemsPerPage]);

  const loadMore = useCallback(async () => {
    if (isLoading || !hasMore) return;

    setIsLoading(true);
    
    // Simulate loading delay for better UX
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const totalPages = Math.ceil(messages.length / itemsPerPage);
    const nextPage = currentPage + 1;
    
    if (nextPage <= totalPages) {
      setCurrentPage(nextPage);
    }
    
    setIsLoading(false);
  }, [isLoading, hasMore, messages.length, itemsPerPage, currentPage]);

  // Scroll event handler
  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (!scrollContainer) return;

    const handleScroll = () => {
      const { scrollTop } = scrollContainer;
      
      // Load more when scrolled to top (within 100px)
      if (scrollTop < 100 && hasMore && !isLoading) {
        loadMore();
      }
    };

    scrollContainer.addEventListener('scroll', handleScroll);
    return () => scrollContainer.removeEventListener('scroll', handleScroll);
  }, [hasMore, isLoading, loadMore, scrollContainerRef]);

  return {
    displayedMessages,
    isLoading,
    hasMore,
    loadMore
  };
};