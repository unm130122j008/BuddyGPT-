import { Message } from '../types';
import { aiService } from '../services/aiService';
import { pluginService } from '../services/pluginService';
import { imageService } from '../services/imageService';
import { fileAnalysisService } from '../services/fileAnalysisService';

// Convert our Message type to AI service format
const convertToAIFormat = (messages: Message[]) => {
  return messages.map(msg => ({
    role: msg.role === 'user' ? 'user' as const : 'assistant' as const,
    content: msg.content
  }));
};

export const generateAIResponse = async (
  userMessage: string, 
  context: Message[], 
  file?: File | null,
  userName?: string
): Promise<{ content: string; pluginData?: any }> => {
  try {
    console.log('🤖 Generating AI Response');
    console.log('👤 User Name:', userName);
    console.log('💬 User Message:', userMessage);
    console.log('📁 File:', file ? `${file.name} (${file.type})` : 'None');

    // Enhanced system prompt for BuddyGPT with personalization
    const systemPrompt = `You are BuddyGPT, an advanced AI assistant with comprehensive file analysis capabilities. You can analyze ANY type of file and provide detailed, professional insights.

${userName ? `## 🎯 **IMPORTANT: User Personalization**
The user's name is "${userName}". ALWAYS address them by their name throughout the conversation. Use their name naturally in responses - for example:
- "Hi ${userName}! I'd be happy to help you with that."
- "Great question, ${userName}! Let me explain..."
- "${userName}, here's what I found..."
- "I understand what you're looking for, ${userName}."

Make the conversation feel personal and friendly by using their name regularly but naturally.` : ''}

## 🎯 **Core Capabilities:**

### 📄 **Document Analysis (PDF, Word, PowerPoint, etc.)**
- **Content Extraction**: Read and summarize all text content
- **Structure Analysis**: Identify headings, sections, key points
- **Data Extraction**: Tables, charts, important metrics
- **Insights**: Provide actionable recommendations and analysis
- **OCR**: Extract text from scanned documents and images

### 🖼️ **Image Analysis**
- **Visual Description**: Detailed description of objects, people, scenes
- **Text Recognition (OCR)**: Extract and read any text in images
- **Technical Analysis**: Colors, composition, style, quality
- **Context Understanding**: Interpret meaning and purpose
- **Metadata**: Dimensions, file size, format details

### 📊 **Spreadsheet Analysis (Excel, CSV)**
- **Data Patterns**: Identify trends, outliers, correlations
- **Statistical Analysis**: Calculate key metrics and insights
- **Business Intelligence**: Provide actionable business insights
- **Data Quality**: Assess completeness and accuracy
- **Visualization Suggestions**: Recommend charts and graphs

### 📝 **Text File Analysis**
- **Content Summarization**: Key points and themes
- **Structure Analysis**: Organization and flow
- **Data Extraction**: Important information and patterns
- **Format Recognition**: JSON, CSV, logs, code files
- **Insights**: Recommendations and next steps

## 🎨 **Response Format Guidelines:**
- Use clear headings with emojis (## 📄 **Document Analysis**)
- Organize information in numbered lists (1. 2. 3.)
- Provide specific, actionable insights
- Include relevant metadata when helpful
- Be comprehensive but concise
- Always offer follow-up suggestions
- ${userName ? `Always use the user's name "${userName}" naturally in responses` : 'Be friendly and personable'}

## 🔍 **Analysis Approach:**
1. **Identify** the file type and purpose
2. **Extract** all relevant content and data
3. **Analyze** patterns, themes, and key information
4. **Summarize** findings in an organized manner
5. **Recommend** actions or next steps
6. **Invite** follow-up questions

When analyzing files, be thorough, professional, and provide genuine value to the user. Extract maximum insights while keeping responses well-organized and actionable.`;

    // Check for image generation request first
    if (imageService.isImageGenerationRequest(userMessage)) {
      const imagePrompt = imageService.extractImagePrompt(userMessage);
      
      // Generate the image
      const imageResult = await imageService.generateImage({
        prompt: imagePrompt,
        model: 'dall-e-3',
        size: '1024x1024',
        quality: 'hd',
        style: 'vivid'
      });
      
      if (imageResult.success && imageResult.imageUrl) {
        const pluginData = {
          type: 'image' as const,
          data: {
            prompt: imagePrompt,
            imageUrl: imageResult.imageUrl,
            isLoading: false
          }
        };
        
        const responseContent = `## 🎨 **Image Generated Successfully!**${userName ? ` for ${userName}` : ''}

**Prompt:** "${imagePrompt}"

${userName ? `${userName}, I've` : 'I\'ve'} created a high-quality image using DALL-E 3 with professional settings. The image is ready for download or viewing in a new tab.

**Features:**
- **Resolution**: 1024x1024 pixels (HD quality)
- **Style**: Vivid and detailed
- **Model**: DALL-E 3 (latest version)

${userName ? `Would you like me to create variations, modify the style, or generate additional images for you, ${userName}?` : 'Would you like me to create variations, modify the style, or generate additional images?'}`;
        
        return {
          content: responseContent,
          pluginData
        };
      } else {
        const errorMessage = imageResult.error || 'Unknown error occurred';
        return {
          content: `## ❌ **Image Generation Failed**

${userName ? `I apologize, ${userName}, but` : 'I apologize, but'} I couldn't generate the image right now. 

**Error:** ${errorMessage}

### 💡 **Tips for Better Image Generation:**
1. **Be Specific**: Include details about objects, colors, style
2. **Set the Scene**: Describe the background and setting
3. **Add Style**: Mention artistic style (realistic, cartoon, abstract)
4. **Include Mood**: Specify lighting and atmosphere
5. **Try Again**: Rephrase your request if it doesn't work

${userName ? `Would you like to try again with a different prompt, ${userName}?` : 'Would you like to try again with a different prompt?'}`
        };
      }
    }

    // Check for other plugin usage
    const pluginDetection = pluginService.detectPlugin(userMessage);
    let pluginData = null;

    if (pluginDetection.type) {
      switch (pluginDetection.type) {
        case 'weather':
          const weatherData = await pluginService.getWeather(pluginDetection.params.location);
          pluginData = { type: 'weather', data: weatherData };
          break;
        case 'calculator':
          const calcData = pluginService.calculate(pluginDetection.params.expression);
          pluginData = { type: 'calculator', data: calcData };
          break;
      }
    }

    // Enhanced file analysis
    let enhancedMessage = userMessage;
    let fileAnalysis = null;

    if (file) {
      try {
        fileAnalysis = await fileAnalysisService.analyzeFile(file);
        const fileSize = (file.size / 1024 / 1024).toFixed(2);
        
        if (file.type.startsWith('image/')) {
          enhancedMessage = `## 🖼️ **Image Analysis Request**${userName ? ` from ${userName}` : ''}

Please provide a comprehensive analysis of this image including:

### 📋 **Analysis Requirements:**
1. **Visual Elements**: Objects, people, animals, and their positions
2. **Colors & Composition**: Color scheme, lighting, artistic style  
3. **Text Content**: Any visible text or writing (OCR analysis)
4. **Context & Setting**: Location, environment, mood, atmosphere
5. **Technical Details**: Image quality, style, notable features
6. **Interpretation**: Meaning, purpose, or story behind the image

**${userName ? `${userName}'s` : 'User\'s'} Question:** ${userMessage}

**File Details:**
- **Name**: ${file.name}
- **Size**: ${fileSize}MB
- **Dimensions**: ${fileAnalysis.metadata.width}x${fileAnalysis.metadata.height} pixels
- **Type**: ${file.type}

${userName ? `Please provide detailed insights for ${userName} and be ready to answer follow-up questions about this image.` : 'Please provide detailed insights and be ready to answer follow-up questions about this image.'}`;

        } else if (file.type === 'application/pdf') {
          enhancedMessage = `## 📄 **PDF Document Analysis Request**${userName ? ` from ${userName}` : ''}

Please analyze this PDF document thoroughly and provide:

### 📋 **Analysis Requirements:**
1. **Document Overview**: Main purpose, type, and summary
2. **Content Structure**: Sections, chapters, headings, organization
3. **Key Information**: Important data, facts, statistics, insights
4. **Tables & Charts**: Any data visualizations or structured data
5. **Actionable Items**: Tasks, recommendations, next steps
6. **Professional Assessment**: Quality, completeness, effectiveness

**${userName ? `${userName}'s` : 'User\'s'} Question:** ${userMessage}

**File Details:**
- **Name**: ${file.name}
- **Size**: ${fileSize}MB
- **Type**: PDF Document
- **Last Modified**: ${new Date(file.lastModified).toLocaleDateString()}

${userName ? `Extract all text content, analyze the structure, and provide comprehensive insights for ${userName}. Be thorough and professional in your analysis.` : 'Extract all text content, analyze the structure, and provide comprehensive insights. Be thorough and professional in your analysis.'}`;

        } else {
          enhancedMessage = `## 📁 **File Analysis Request**${userName ? ` from ${userName}` : ''}

Please analyze this uploaded file and provide comprehensive insights:

**${userName ? `${userName}'s` : 'User\'s'} Question:** ${userMessage}

**File Details:**
- **Name**: ${file.name}
- **Size**: ${fileSize}MB
- **Type**: ${file.type}
- **Last Modified**: ${new Date(file.lastModified).toLocaleDateString()}

${userName ? `Provide detailed analysis based on the file type and content, extracting maximum value and insights for ${userName}.` : 'Provide detailed analysis based on the file type and content, extracting maximum value and insights for the user.'}`;
        }
      } catch (error) {
        console.error('File analysis error:', error);
        enhancedMessage = `## ⚠️ **File Analysis Error**

${userName ? `I encountered an issue analyzing your file "${file.name}", ${userName}. However, I can still help you with:` : `I encountered an issue analyzing your file "${file.name}". However, I can still help you with:`}

**${userName ? `${userName}'s` : 'User\'s'} Question:** ${userMessage}

**File Details:**
- **Name**: ${file.name}
- **Size**: ${(file.size / 1024 / 1024).toFixed(2)}MB
- **Type**: ${file.type}

${userName ? `Please let me know what specific information you'd like to extract or analyze from this file, ${userName}, and I'll do my best to help you.` : 'Please let me know what specific information you\'d like to extract or analyze from this file, and I\'ll do my best to help you.'}`;
      }
    }

    // Add plugin context to the message
    if (pluginData) {
      switch (pluginData.type) {
        case 'weather':
          enhancedMessage += `\n\n## 🌤️ **Weather Information Retrieved**\n${userName ? `Weather data for ${pluginData.data.location} has been displayed above for ${userName}. Please provide additional context or insights about the current weather conditions.` : `Weather data for ${pluginData.data.location} has been displayed above. Please provide additional context or insights about the current weather conditions.`}`;
          break;
        case 'calculator':
          enhancedMessage += `\n\n## 🧮 **Calculation Completed**\n${userName ? `The calculation result has been displayed above for ${userName}. Please explain the mathematical process or provide additional insights if relevant.` : 'The calculation result has been displayed above. Please explain the mathematical process or provide additional insights if relevant.'}`;
          break;
      }
    }

    // Convert conversation history to AI service format
    const conversationHistory = convertToAIFormat(context);
    
    // Add system prompt to conversation
    const messagesWithSystem = [
      { role: 'system' as const, content: systemPrompt },
      ...conversationHistory
    ];
    
    console.log('🔄 Calling AI Service...');
    
    // Generate response using AI service (auto-selects best provider)
    let response = await aiService.generateResponse(enhancedMessage, messagesWithSystem);
    
    console.log('✅ AI Response Generated:', response.substring(0, 100) + '...');
    
    // Enhance response formatting for file analysis
    if (file && !response.includes('##')) {
      const fileType = file.type.startsWith('image/') ? 'Image' : 
                      file.type === 'application/pdf' ? 'PDF Document' :
                      file.type.includes('word') ? 'Word Document' :
                      file.type.includes('excel') ? 'Spreadsheet' :
                      file.type.includes('powerpoint') ? 'Presentation' : 'File';
      
      response = `## 📄 **${fileType} Analysis**${userName ? ` for ${userName}` : ''}\n\n${response}`;
    }
    
    return {
      content: response,
      pluginData
    };
  } catch (error) {
    console.error('❌ Error generating AI response:', error);
    
    return {
      content: `## ❌ **Error Processing Request**

${userName ? `I apologize, ${userName}, but` : 'I apologize, but'} I encountered an error while processing your request. This might be due to:

1. **API Issues**: Problem connecting to Gemini API
2. **Network Issues**: Please check your internet connection
3. **File Size**: Try with a smaller file (under 25MB)
4. **File Format**: Ensure the file is in a supported format
5. **Temporary Issue**: Please try again in a moment

**Error Details**: ${error instanceof Error ? error.message : 'Unknown error'}

**Troubleshooting:**
- Check browser console for detailed error logs
- Verify your Gemini API key is working
- Try a simpler message first
- Refresh the page and try again

${userName ? `Please try again, ${userName}, or let me know if you need help with the API setup.` : 'Please try again or let me know if you need help with the API setup.'}`
    };
  }
};

// Export the service for direct access if needed
export { aiService };