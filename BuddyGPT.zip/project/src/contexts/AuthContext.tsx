import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  id: string;
  name: string;
  email?: string;
  photoURL?: string;
  displayName?: string;
}

interface AuthContextType {
  currentUser: User | null;
  loginWithName: (name: string) => Promise<void>;
  logout: () => Promise<void>;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Load user from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('buddygpt-user');
    if (savedUser) {
      try {
        const user = JSON.parse(savedUser);
        setCurrentUser(user);
      } catch (error) {
        console.error('Error loading saved user:', error);
        localStorage.removeItem('buddygpt-user');
      }
    }
    setLoading(false);
  }, []);

  const loginWithName = async (name: string) => {
    try {
      const user: User = {
        id: Date.now().toString(), // Simple ID generation
        name: name,
        displayName: name,
        email: `${name.toLowerCase().replace(/\s+/g, '')}@buddygpt.local`
      };
      
      setCurrentUser(user);
      localStorage.setItem('buddygpt-user', JSON.stringify(user));
      console.log('User logged in with name:', name);
    } catch (error) {
      console.error('Error setting user name:', error);
      throw new Error('Failed to set user name. Please try again.');
    }
  };

  const logout = async () => {
    try {
      setCurrentUser(null);
      localStorage.removeItem('buddygpt-user');
      console.log('User logged out');
    } catch (error) {
      console.error('Error logging out:', error);
      throw new Error('Failed to log out. Please try again.');
    }
  };

  const value = {
    currentUser,
    loginWithName,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};