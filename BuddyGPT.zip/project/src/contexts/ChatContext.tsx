import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { Chat, Message } from '../types';
import { useIncognito } from './IncognitoContext';
import { useAuth } from './AuthContext';
import { generateAIResponse } from '../utils/aiResponses';

interface ChatContextType {
  chats: Chat[];
  currentChat: Chat | null;
  isTyping: boolean;
  lastUserMessage: string;
  createNewChat: () => void;
  selectChat: (chatId: string) => void;
  sendMessage: (content: string, file?: File | null) => Promise<void>;
  deleteChat: (chatId: string) => void;
  hasRecentActivity: () => boolean;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const useChat = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [currentChat, setCurrentChat] = useState<Chat | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [lastUserMessage, setLastUserMessage] = useState('');
  const { isIncognitoMode } = useIncognito();
  const { currentUser } = useAuth();

  // Load chats from localStorage on component mount (only if not in incognito mode)
  useEffect(() => {
    if (isIncognitoMode) {
      // In incognito mode, start fresh
      setChats([]);
      setCurrentChat(null);
      return;
    }

    const savedChats = localStorage.getItem('buddygpt-chats');
    const savedCurrentChatId = localStorage.getItem('buddygpt-current-chat');
    
    if (savedChats) {
      try {
        const parsedChats = JSON.parse(savedChats).map((chat: any) => ({
          ...chat,
          createdAt: new Date(chat.createdAt),
          updatedAt: new Date(chat.updatedAt),
          messages: chat.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          }))
        }));
        
        setChats(parsedChats);
        
        if (savedCurrentChatId) {
          const currentChat = parsedChats.find((chat: Chat) => chat.id === savedCurrentChatId);
          if (currentChat) {
            setCurrentChat(currentChat);
          }
        }
      } catch (error) {
        console.error('Error loading saved chats:', error);
      }
    }
  }, [isIncognitoMode]);

  // Save chats to localStorage whenever chats change (only if not in incognito mode)
  useEffect(() => {
    if (!isIncognitoMode && chats.length > 0) {
      localStorage.setItem('buddygpt-chats', JSON.stringify(chats));
    }
  }, [chats, isIncognitoMode]);

  // Save current chat ID to localStorage whenever it changes (only if not in incognito mode)
  useEffect(() => {
    if (!isIncognitoMode && currentChat) {
      localStorage.setItem('buddygpt-current-chat', currentChat.id);
    }
  }, [currentChat, isIncognitoMode]);

  // Clear data when entering incognito mode
  useEffect(() => {
    if (isIncognitoMode) {
      // Clear any existing data when entering incognito mode
      setChats([]);
      setCurrentChat(null);
      setLastUserMessage('');
    }
  }, [isIncognitoMode]);

  const createNewChat = useCallback(() => {
    const newChat: Chat = {
      id: Date.now().toString(),
      title: 'New Chat',
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    
    setChats(prev => [newChat, ...prev]);
    setCurrentChat(newChat);
    return newChat;
  }, []);

  const selectChat = useCallback((chatId: string) => {
    const chat = chats.find(c => c.id === chatId);
    if (chat) {
      setCurrentChat(chat);
    }
  }, [chats]);

  const sendMessage = useCallback(async (content: string, file?: File | null) => {
    let chatToUse = currentChat;
    
    // Auto-create a new chat if none exists
    if (!chatToUse) {
      chatToUse = createNewChat();
    }

    setLastUserMessage(content);

    const userMessage: Message = {
      id: Date.now().toString(),
      content,
      role: 'user',
      timestamp: new Date(),
      fileInfo: file ? {
        name: file.name,
        type: file.type,
        size: `${(file.size / 1024).toFixed(1)} KB`
      } : undefined,
    };

    // Update current chat with user message
    const updatedChat = {
      ...chatToUse,
      messages: [...chatToUse.messages, userMessage],
      title: chatToUse.messages.length === 0 ? content.slice(0, 30) + '...' : chatToUse.title,
      updatedAt: new Date(),
    };

    setCurrentChat(updatedChat);
    setChats(prev => prev.map(c => c.id === updatedChat.id ? updatedChat : c));

    // Show enhanced typing indicator
    setIsTyping(true);

    // Simulate AI response delay with more realistic timing
    await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 2500));

    // Pass user name to AI response generation
    const aiResponse = await generateAIResponse(content, updatedChat.messages, file, currentUser?.name);
    
    // Clean up response formatting - remove excessive asterisks and improve structure
    const enhancedContent = cleanResponseFormatting(aiResponse.content);
    
    const assistantMessage: Message = {
      id: (Date.now() + 1).toString(),
      content: enhancedContent,
      role: 'assistant',
      timestamp: new Date(),
      pluginData: aiResponse.pluginData,
    };

    const finalChat = {
      ...updatedChat,
      messages: [...updatedChat.messages, assistantMessage],
      updatedAt: new Date(),
    };

    setCurrentChat(finalChat);
    setChats(prev => prev.map(c => c.id === finalChat.id ? finalChat : c));
    setIsTyping(false);
  }, [currentChat, createNewChat, currentUser?.name]);

  const deleteChat = useCallback((chatId: string) => {
    setChats(prev => {
      const newChats = prev.filter(c => c.id !== chatId);
      // Update localStorage immediately (only if not in incognito mode)
      if (!isIncognitoMode) {
        localStorage.setItem('buddygpt-chats', JSON.stringify(newChats));
      }
      return newChats;
    });
    
    if (currentChat?.id === chatId) {
      setCurrentChat(null);
      if (!isIncognitoMode) {
        localStorage.removeItem('buddygpt-current-chat');
      }
    }
  }, [currentChat, isIncognitoMode]);

  const hasRecentActivity = useCallback(() => {
    if (!currentChat || currentChat.messages.length === 0) return false;
    const lastMessage = currentChat.messages[currentChat.messages.length - 1];
    const timeDiff = Date.now() - lastMessage.timestamp.getTime();
    return timeDiff < 300000; // 5 minutes
  }, [currentChat]);

  return (
    <ChatContext.Provider value={{
      chats,
      currentChat,
      isTyping,
      lastUserMessage,
      createNewChat,
      selectChat,
      sendMessage,
      deleteChat,
      hasRecentActivity,
    }}>
      {children}
    </ChatContext.Provider>
  );
};

// Helper function to clean up response formatting
function cleanResponseFormatting(content: string): string {
  return content
    // Replace multiple asterisks with numbered lists
    .replace(/\*\*\*([^*]+)\*\*\*/g, '$1')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1')
    // Clean up excessive formatting
    .replace(/(\*){3,}/g, '')
    // Ensure proper spacing
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}