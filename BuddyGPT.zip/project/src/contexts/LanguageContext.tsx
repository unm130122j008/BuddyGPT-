import React, { createContext, useContext, useState, useEffect } from 'react';
import { useIncognito } from './IncognitoContext';

export type Language = 'en' | 'es' | 'fr' | 'de' | 'zh' | 'ja' | 'ko' | 'ar' | 'ta';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

// Translation dictionary
const translations: Record<Language, Record<string, string>> = {
  en: {
    // Header
    'buddygpt': 'BuddyGPT',
    'messages': 'messages',
    'active': 'BuddyGPT Active ✨',
    'insights': 'View Conversation Insights',
    'profile': 'User Profile',
    
    // Welcome Screen
    'welcome_title': 'Hey there! I\'m BuddyGPT! 👋',
    'welcome_subtitle': 'Ready to chat, create, or help with something cool? ✨',
    'weather_updates': 'Weather Updates',
    'weather_desc': 'Get current weather for any location',
    'latest_news': 'Latest News',
    'news_desc': 'Stay updated with breaking news',
    'smart_calculator': 'Smart Calculator',
    'calculator_desc': 'Solve complex mathematical problems',
    'multilingual': '🌍 I speak all languages fluently - chat in your preferred language!',
    
    // Sidebar
    'new_chat': 'New Chat',
    'total_messages': 'Messages',
    'total_chats': 'Chats',
    
    // Profile
    'guest_user': 'Guest User',
    'companion': 'BuddyGPT Companion',
    'theme': 'Theme',
    'light': 'Light',
    'dark': 'Dark',
    'language': 'Language',
    'advanced_settings': 'Advanced Settings',
    
    // Incognito Mode
    'incognito_mode': 'Incognito Mode',
    'incognito': 'Incognito',
    'incognito_description': 'Browse privately without saving history',
    'incognito_active': 'Incognito Mode Active',
    'incognito_mode_active': 'Incognito mode is active',
    'normal_mode_active': 'Normal Mode Active',
    'normal_mode_description': 'Your conversations and preferences are being saved for a personalized experience.',
    'does_not_save': 'Does NOT save',
    'chat_history': 'Chat history',
    'search_history': 'Search history',
    'user_preferences': 'User preferences',
    'conversation_insights': 'Conversation insights',
    'contextual_memory': 'Contextual memory',
    'privacy_notice': 'Privacy Notice',
    'privacy_notice_text': 'In incognito mode, your data is not stored locally. However, conversations are still processed by AI services. Always review privacy policies of AI providers.',
    'close': 'Close',
    
    // Tools
    'tools': 'Tools',
    'weather': 'Weather',
    'weather_tool_desc': 'Get current weather information',
    'news': 'News',
    'news_tool_desc': 'Latest news and headlines',
    'calculator': 'Calculator',
    'calculator_tool_desc': 'Advanced mathematical calculations',
    'document_analyzer': 'Document Analyzer',
    'document_desc': 'Analyze PDFs and documents',
    'image_creator': 'Image Creator',
    'image_desc': 'AI-powered image generation',
    'get_weather': 'Get Weather',
    'get_news': 'Get News',
    'calculate': 'Calculate',
    'enter_city': 'Enter city name...',
    'search_topic': 'Search topic (optional)...',
    'enter_expression': 'Enter expression (e.g., 2+2*3)...',
    
    // Input
    'message_placeholder': 'Message BuddyGPT or paste an image (Ctrl+V)... 🌍✨',
    'image_placeholder': 'Ask me about this image... 🖼️',
    'open_tools': 'Open Tools',
    
    // Message Actions
    'copy_message': 'Copy message',
    'good_response': 'Good response',
    'bad_response': 'Bad response',
    'thanks_feedback': 'Thanks! 👍',
    'feedback_noted': 'Noted 📝',
    
    // Quotes
    'next_quote': 'Next quote',
    
    // Scroll
    'back_to_top': 'Back to top',
    'loading_messages': 'Loading more messages...',
    'scroll_load_more': 'Scroll up to load more',
    'conversation_beginning': 'Beginning of conversation',
    
    // Footer
    'footer_desc': 'Empowering conversations with advanced AI technology. Chat, create, and explore with your intelligent digital companion',
    'connect_developer': 'Connect with Developer',
    'made_with': 'Made with',
    'copyright': '© 2025 BuddyGPT'
  },
  
  ta: {
    // Header
    'buddygpt': 'பட்டிஜிபிடி',
    'messages': 'செய்திகள்',
    'active': 'பட்டிஜிபிடி செயலில் ✨',
    'insights': 'உரையாடல் நுண்ணறிவுகளைப் பார்க்கவும்',
    'profile': 'பயனர் சுயவிவரம்',
    
    // Welcome Screen
    'welcome_title': 'வணக்கம்! நான் பட்டிஜிபிடி! 👋',
    'welcome_subtitle': 'அரட்டை, உருவாக்கம் அல்லது ஏதாவது சுவாரஸ்யமான உதவிக்கு தயாரா? ✨',
    'weather_updates': 'வானிலை புதுப்பிப்புகள்',
    'weather_desc': 'எந்த இடத்திற்கும் தற்போதைய வானிலையைப் பெறுங்கள்',
    'latest_news': 'சமீபத்திய செய்திகள்',
    'news_desc': 'முக்கிய செய்திகளுடன் புதுப்பித்த நிலையில் இருங்கள்',
    'smart_calculator': 'ஸ்மார்ட் கால்குலேட்டர்',
    'calculator_desc': 'சிக்கலான கணித சிக்கல்களைத் தீர்க்கவும்',
    'multilingual': '🌍 நான் அனைத்து மொழிகளையும் சரளமாக பேசுகிறேன் - உங்கள் விருப்பமான மொழியில் அரட்டையடியுங்கள்!',
    
    // Sidebar
    'new_chat': 'புதிய அரட்டை',
    'total_messages': 'செய்திகள்',
    'total_chats': 'அரட்டைகள்',
    
    // Profile
    'guest_user': 'விருந்தினர் பயனர்',
    'companion': 'பட்டிஜிபிடி துணை',
    'theme': 'தீம்',
    'light': 'வெளிச்சம்',
    'dark': 'இருள்',
    'language': 'மொழி',
    'advanced_settings': 'மேம்பட்ட அமைப்புகள்',
    
    // Incognito Mode
    'incognito_mode': 'மறைநிலை பயன்முறை',
    'incognito': 'மறைநிலை',
    'incognito_description': 'வரலாற்றைச் சேமிக்காமல் தனிப்பட்ட முறையில் உலாவுங்கள்',
    'incognito_active': 'மறைநிலை பயன்முறை செயலில்',
    'incognito_mode_active': 'மறைநிலை பயன்முறை செயலில் உள்ளது',
    'normal_mode_active': 'சாதாரண பயன்முறை செயலில்',
    'normal_mode_description': 'தனிப்பயனாக்கப்பட்ட அனுபவத்திற்காக உங்கள் உரையாடல்கள் மற்றும் விருப்பத்தேர்வுகள் சேமிக்கப்படுகின்றன.',
    'does_not_save': 'சேமிக்காது',
    'chat_history': 'அரட்டை வரலாறு',
    'search_history': 'தேடல் வரலாறு',
    'user_preferences': 'பயனர் விருப்பத்தேர்வுகள்',
    'conversation_insights': 'உரையாடல் நுண்ணறிவுகள்',
    'contextual_memory': 'சூழல் நினைவகம்',
    'privacy_notice': 'தனியுரிமை அறிவிப்பு',
    'privacy_notice_text': 'மறைநிலை பயன்முறையில், உங்கள் தரவு உள்ளூரில் சேமிக்கப்படாது. இருப்பினும், உரையாடல்கள் இன்னும் AI சேவைகளால் செயலாக்கப்படுகின்றன. AI வழங்குநர்களின் தனியுரிமைக் கொள்கைகளை எப்போதும் மதிப்பாய்வு செய்யுங்கள்.',
    'close': 'மூடு',
    
    // Tools
    'tools': 'கருவிகள்',
    'weather': 'வானிலை',
    'weather_tool_desc': 'தற்போதைய வானிலை தகவலைப் பெறுங்கள்',
    'news': 'செய்திகள்',
    'news_tool_desc': 'சமீபத்திய செய்திகள் மற்றும் தலைப்புகள்',
    'calculator': 'கால்குலேட்டர்',
    'calculator_tool_desc': 'மேம்பட்ட கணித கணக்கீடுகள்',
    'document_analyzer': 'ஆவண பகுப்பாய்வி',
    'document_desc': 'PDF மற்றும் ஆவணங்களை பகுப்பாய்வு செய்யுங்கள்',
    'image_creator': 'படம் உருவாக்குபவர்',
    'image_desc': 'AI-இயங்கும் படம் உருவாக்கம்',
    'get_weather': 'வானிலையைப் பெறுங்கள்',
    'get_news': 'செய்திகளைப் பெறுங்கள்',
    'calculate': 'கணக்கிடுங்கள்',
    'enter_city': 'நகரத்தின் பெயரை உள்ளிடுங்கள்...',
    'search_topic': 'தலைப்பைத் தேடுங்கள் (விருப்பமானது)...',
    'enter_expression': 'வெளிப்பாட்டை உள்ளிடுங்கள் (எ.கா., 2+2*3)...',
    
    // Input
    'message_placeholder': 'பட்டிஜிபிடிக்கு செய்தி அனுப்புங்கள் அல்லது படத்தை ஒட்டுங்கள் (Ctrl+V)... 🌍✨',
    'image_placeholder': 'இந்த படத்தைப் பற்றி என்னிடம் கேளுங்கள்... 🖼️',
    'open_tools': 'கருவிகளைத் திறக்கவும்',
    
    // Message Actions
    'copy_message': 'செய்தியை நகலெடுக்கவும்',
    'good_response': 'நல்ல பதில்',
    'bad_response': 'மோசமான பதில்',
    'thanks_feedback': 'நன்றி! 👍',
    'feedback_noted': 'குறிப்பிடப்பட்டது 📝',
    
    // Quotes
    'next_quote': 'அடுத்த மேற்கோள்',
    
    // Scroll
    'back_to_top': 'மேலே திரும்பு',
    'loading_messages': 'மேலும் செய்திகளை ஏற்றுகிறது...',
    'scroll_load_more': 'மேலும் ஏற்ற மேலே உருட்டவும்',
    'conversation_beginning': 'உரையாடலின் தொடக்கம்',
    
    // Footer
    'footer_desc': 'மேம்பட்ட AI தொழில்நுட்பத்துடன் உரையாடல்களை மேம்படுத்துதல். உங்கள் அறிவார்ந்த டிஜிட்டல் துணையுடன் அரட்டை, உருவாக்கம் மற்றும் ஆராய்ச்சி',
    'connect_developer': 'டெவலப்பருடன் இணைக்கவும்',
    'made_with': 'அன்புடன் உருவாக்கப்பட்டது',
    'copyright': '© 2025 பட்டிஜிபிடி'
  },
  
  es: {
    // Header
    'buddygpt': 'BuddyGPT',
    'messages': 'mensajes',
    'active': 'BuddyGPT Activo ✨',
    'insights': 'Ver Perspectivas de Conversación',
    'profile': 'Perfil de Usuario',
    
    // Welcome Screen
    'welcome_title': '¡Hola! ¡Soy BuddyGPT! 👋',
    'welcome_subtitle': '¿Listo para chatear, crear o ayudar con algo genial? ✨',
    'weather_updates': 'Actualizaciones del Clima',
    'weather_desc': 'Obtén el clima actual para cualquier ubicación',
    'latest_news': 'Últimas Noticias',
    'news_desc': 'Mantente actualizado con noticias de última hora',
    'smart_calculator': 'Calculadora Inteligente',
    'calculator_desc': 'Resuelve problemas matemáticos complejos',
    'multilingual': '🌍 ¡Hablo todos los idiomas con fluidez - chatea en tu idioma preferido!',
    
    // Sidebar
    'new_chat': 'Nuevo Chat',
    'total_messages': 'Mensajes',
    'total_chats': 'Chats',
    
    // Profile
    'guest_user': 'Usuario Invitado',
    'companion': 'Compañero BuddyGPT',
    'theme': 'Tema',
    'light': 'Claro',
    'dark': 'Oscuro',
    'language': 'Idioma',
    'advanced_settings': 'Configuración Avanzada',
    
    // Incognito Mode
    'incognito_mode': 'Modo Incógnito',
    'incognito': 'Incógnito',
    'incognito_description': 'Navega de forma privada sin guardar historial',
    'incognito_active': 'Modo Incógnito Activo',
    'incognito_mode_active': 'El modo incógnito está activo',
    'normal_mode_active': 'Modo Normal Activo',
    'normal_mode_description': 'Tus conversaciones y preferencias se guardan para una experiencia personalizada.',
    'does_not_save': 'NO guarda',
    'chat_history': 'Historial de chat',
    'search_history': 'Historial de búsqueda',
    'user_preferences': 'Preferencias del usuario',
    'conversation_insights': 'Perspectivas de conversación',
    'contextual_memory': 'Memoria contextual',
    'privacy_notice': 'Aviso de Privacidad',
    'privacy_notice_text': 'En modo incógnito, tus datos no se almacenan localmente. Sin embargo, las conversaciones aún son procesadas por servicios de IA. Siempre revisa las políticas de privacidad de los proveedores de IA.',
    'close': 'Cerrar',
    
    // Tools
    'tools': 'Herramientas',
    'weather': 'Clima',
    'weather_tool_desc': 'Obtener información meteorológica actual',
    'news': 'Noticias',
    'news_tool_desc': 'Últimas noticias y titulares',
    'calculator': 'Calculadora',
    'calculator_tool_desc': 'Cálculos matemáticos avanzados',
    'document_analyzer': 'Analizador de Documentos',
    'document_desc': 'Analizar PDFs y documentos',
    'image_creator': 'Creador de Imágenes',
    'image_desc': 'Generación de imágenes con IA',
    'get_weather': 'Obtener Clima',
    'get_news': 'Obtener Noticias',
    'calculate': 'Calcular',
    'enter_city': 'Ingresa el nombre de la ciudad...',
    'search_topic': 'Buscar tema (opcional)...',
    'enter_expression': 'Ingresa expresión (ej., 2+2*3)...',
    
    // Input
    'message_placeholder': 'Mensaje a BuddyGPT o pega una imagen (Ctrl+V)... 🌍✨',
    'image_placeholder': 'Pregúntame sobre esta imagen... 🖼️',
    'open_tools': 'Abrir Herramientas',
    
    // Message Actions
    'copy_message': 'Copiar mensaje',
    'good_response': 'Buena respuesta',
    'bad_response': 'Mala respuesta',
    'thanks_feedback': '¡Gracias! 👍',
    'feedback_noted': 'Anotado 📝',
    
    // Quotes
    'next_quote': 'Siguiente cita',
    
    // Scroll
    'back_to_top': 'Volver arriba',
    'loading_messages': 'Cargando más mensajes...',
    'scroll_load_more': 'Desplázate hacia arriba para cargar más',
    'conversation_beginning': 'Inicio de la conversación',
    
    // Footer
    'footer_desc': 'Potenciando conversaciones con tecnología AI avanzada. Chatea, crea y explora con tu compañero digital inteligente',
    'connect_developer': 'Conectar con Desarrollador',
    'made_with': 'Hecho con',
    'copyright': '© 2025 BuddyGPT'
  },
  
  fr: {
    // Header
    'buddygpt': 'BuddyGPT',
    'messages': 'messages',
    'active': 'BuddyGPT Actif ✨',
    'insights': 'Voir les Perspectives de Conversation',
    'profile': 'Profil Utilisateur',
    
    // Welcome Screen
    'welcome_title': 'Salut ! Je suis BuddyGPT ! 👋',
    'welcome_subtitle': 'Prêt à discuter, créer ou aider avec quelque chose de cool ? ✨',
    'weather_updates': 'Mises à Jour Météo',
    'weather_desc': 'Obtenez la météo actuelle pour n\'importe quel endroit',
    'latest_news': 'Dernières Nouvelles',
    'news_desc': 'Restez à jour avec les dernières nouvelles',
    'smart_calculator': 'Calculatrice Intelligente',
    'calculator_desc': 'Résolvez des problèmes mathématiques complexes',
    'multilingual': '🌍 Je parle couramment toutes les langues - discutez dans votre langue préférée !',
    
    // Sidebar
    'new_chat': 'Nouveau Chat',
    'total_messages': 'Messages',
    'total_chats': 'Chats',
    
    // Profile
    'guest_user': 'Utilisateur Invité',
    'companion': 'Compagnon BuddyGPT',
    'theme': 'Thème',
    'light': 'Clair',
    'dark': 'Sombre',
    'language': 'Langue',
    'advanced_settings': 'Paramètres Avancés',
    
    // Tools
    'tools': 'Outils',
    'weather': 'Météo',
    'weather_tool_desc': 'Obtenir des informations météorologiques actuelles',
    'news': 'Nouvelles',
    'news_tool_desc': 'Dernières nouvelles et gros titres',
    'calculator': 'Calculatrice',
    'calculator_tool_desc': 'Calculs mathématiques avancés',
    'document_analyzer': 'Analyseur de Documents',
    'document_desc': 'Analyser les PDFs et documents',
    'image_creator': 'Créateur d\'Images',
    'image_desc': 'Génération d\'images par IA',
    'get_weather': 'Obtenir Météo',
    'get_news': 'Obtenir Nouvelles',
    'calculate': 'Calculer',
    'enter_city': 'Entrez le nom de la ville...',
    'search_topic': 'Rechercher un sujet (optionnel)...',
    'enter_expression': 'Entrez l\'expression (ex., 2+2*3)...',
    
    // Input
    'message_placeholder': 'Message à BuddyGPT ou collez une image (Ctrl+V)... 🌍✨',
    'image_placeholder': 'Demandez-moi à propos de cette image... 🖼️',
    'open_tools': 'Ouvrir Outils',
    
    // Message Actions
    'copy_message': 'Copier le message',
    'good_response': 'Bonne réponse',
    'bad_response': 'Mauvaise réponse',
    'thanks_feedback': 'Merci ! 👍',
    'feedback_noted': 'Noté 📝',
    
    // Quotes
    'next_quote': 'Citation suivante',
    
    // Scroll
    'back_to_top': 'Retour en haut',
    'loading_messages': 'Chargement de plus de messages...',
    'scroll_load_more': 'Faites défiler vers le haut pour charger plus',
    'conversation_beginning': 'Début de la conversation',
    
    // Footer
    'footer_desc': 'Autonomiser les conversations avec une technologie IA avancée. Discutez, créez et explorez avec votre compagnon numérique intelligent',
    'connect_developer': 'Se Connecter au Développeur',
    'made_with': 'Fait avec',
    'copyright': '© 2025 BuddyGPT'
  },
  
  de: {
    // Header
    'buddygpt': 'BuddyGPT',
    'messages': 'Nachrichten',
    'active': 'BuddyGPT Aktiv ✨',
    'insights': 'Gesprächseinblicke Anzeigen',
    'profile': 'Benutzerprofil',
    
    // Welcome Screen
    'welcome_title': 'Hallo! Ich bin BuddyGPT! 👋',
    'welcome_subtitle': 'Bereit zu chatten, zu erstellen oder bei etwas Coolem zu helfen? ✨',
    'weather_updates': 'Wetter-Updates',
    'weather_desc': 'Aktuelles Wetter für jeden Ort abrufen',
    'latest_news': 'Neueste Nachrichten',
    'news_desc': 'Bleiben Sie mit aktuellen Nachrichten auf dem Laufenden',
    'smart_calculator': 'Intelligenter Rechner',
    'calculator_desc': 'Komplexe mathematische Probleme lösen',
    'multilingual': '🌍 Ich spreche alle Sprachen fließend - chatten Sie in Ihrer bevorzugten Sprache!',
    
    // Sidebar
    'new_chat': 'Neuer Chat',
    'total_messages': 'Nachrichten',
    'total_chats': 'Chats',
    
    // Profile
    'guest_user': 'Gastbenutzer',
    'companion': 'BuddyGPT Begleiter',
    'theme': 'Design',
    'light': 'Hell',
    'dark': 'Dunkel',
    'language': 'Sprache',
    'advanced_settings': 'Erweiterte Einstellungen',
    
    // Tools
    'tools': 'Werkzeuge',
    'weather': 'Wetter',
    'weather_tool_desc': 'Aktuelle Wetterinformationen abrufen',
    'news': 'Nachrichten',
    'news_tool_desc': 'Neueste Nachrichten und Schlagzeilen',
    'calculator': 'Rechner',
    'calculator_tool_desc': 'Erweiterte mathematische Berechnungen',
    'document_analyzer': 'Dokumentenanalysator',
    'document_desc': 'PDFs und Dokumente analysieren',
    'image_creator': 'Bildersteller',
    'image_desc': 'KI-gestützte Bilderzeugung',
    'get_weather': 'Wetter Abrufen',
    'get_news': 'Nachrichten Abrufen',
    'calculate': 'Berechnen',
    'enter_city': 'Stadtname eingeben...',
    'search_topic': 'Thema suchen (optional)...',
    'enter_expression': 'Ausdruck eingeben (z.B., 2+2*3)...',
    
    // Input
    'message_placeholder': 'Nachricht an BuddyGPT oder Bild einfügen (Ctrl+V)... 🌍✨',
    'image_placeholder': 'Fragen Sie mich zu diesem Bild... 🖼️',
    'open_tools': 'Werkzeuge Öffnen',
    
    // Message Actions
    'copy_message': 'Nachricht kopieren',
    'good_response': 'Gute Antwort',
    'bad_response': 'Schlechte Antwort',
    'thanks_feedback': 'Danke! 👍',
    'feedback_noted': 'Notiert 📝',
    
    // Quotes
    'next_quote': 'Nächstes Zitat',
    
    // Scroll
    'back_to_top': 'Nach oben',
    'loading_messages': 'Weitere Nachrichten laden...',
    'scroll_load_more': 'Nach oben scrollen, um mehr zu laden',
    'conversation_beginning': 'Gesprächsbeginn',
    
    // Footer
    'footer_desc': 'Gespräche mit fortschrittlicher KI-Technologie stärken. Chatten, erstellen und erkunden Sie mit Ihrem intelligenten digitalen Begleiter',
    'connect_developer': 'Mit Entwickler Verbinden',
    'made_with': 'Gemacht mit',
    'copyright': '© 2025 BuddyGPT'
  },
  
  zh: {
    // Header
    'buddygpt': 'BuddyGPT',
    'messages': '消息',
    'active': 'BuddyGPT 活跃 ✨',
    'insights': '查看对话洞察',
    'profile': '用户资料',
    
    // Welcome Screen
    'welcome_title': '你好！我是 BuddyGPT！👋',
    'welcome_subtitle': '准备聊天、创作或帮助做一些酷的事情吗？✨',
    'weather_updates': '天气更新',
    'weather_desc': '获取任何地点的当前天气',
    'latest_news': '最新新闻',
    'news_desc': '及时了解突发新闻',
    'smart_calculator': '智能计算器',
    'calculator_desc': '解决复杂的数学问题',
    'multilingual': '🌍 我流利地说所有语言 - 用你喜欢的语言聊天！',
    
    // Sidebar
    'new_chat': '新聊天',
    'total_messages': '消息',
    'total_chats': '聊天',
    
    // Profile
    'guest_user': '访客用户',
    'companion': 'BuddyGPT 伴侣',
    'theme': '主题',
    'light': '浅色',
    'dark': '深色',
    'language': '语言',
    'advanced_settings': '高级设置',
    
    // Tools
    'tools': '工具',
    'weather': '天气',
    'weather_tool_desc': '获取当前天气信息',
    'news': '新闻',
    'news_tool_desc': '最新新闻和头条',
    'calculator': '计算器',
    'calculator_tool_desc': '高级数学计算',
    'document_analyzer': '文档分析器',
    'document_desc': '分析PDF和文档',
    'image_creator': '图像创建器',
    'image_desc': 'AI驱动的图像生成',
    'get_weather': '获取天气',
    'get_news': '获取新闻',
    'calculate': '计算',
    'enter_city': '输入城市名称...',
    'search_topic': '搜索主题（可选）...',
    'enter_expression': '输入表达式（例如，2+2*3）...',
    
    // Input
    'message_placeholder': '给 BuddyGPT 发消息或粘贴图片 (Ctrl+V)... 🌍✨',
    'image_placeholder': '问我关于这张图片... 🖼️',
    'open_tools': '打开工具',
    
    // Message Actions
    'copy_message': '复制消息',
    'good_response': '好回答',
    'bad_response': '坏回答',
    'thanks_feedback': '谢谢！👍',
    'feedback_noted': '已记录 📝',
    
    // Quotes
    'next_quote': '下一句话',
    
    // Scroll
    'back_to_top': '回到顶部',
    'loading_messages': '加载更多消息...',
    'scroll_load_more': '向上滚动加载更多',
    'conversation_beginning': '对话开始',
    
    // Footer
    'footer_desc': '用先进的AI技术增强对话。与您的智能数字伴侣聊天、创作和探索',
    'connect_developer': '联系开发者',
    'made_with': '用爱制作',
    'copyright': '© 2025 BuddyGPT'
  },
  
  ja: {
    // Header
    'buddygpt': 'BuddyGPT',
    'messages': 'メッセージ',
    'active': 'BuddyGPT アクティブ ✨',
    'insights': '会話の洞察を表示',
    'profile': 'ユーザープロフィール',
    
    // Welcome Screen
    'welcome_title': 'こんにちは！私はBuddyGPTです！👋',
    'welcome_subtitle': 'チャット、作成、またはクールなことのお手伝いの準備はできていますか？✨',
    'weather_updates': '天気更新',
    'weather_desc': '任意の場所の現在の天気を取得',
    'latest_news': '最新ニュース',
    'news_desc': '速報ニュースで最新情報を入手',
    'smart_calculator': 'スマート電卓',
    'calculator_desc': '複雑な数学問題を解決',
    'multilingual': '🌍 私はすべての言語を流暢に話します - お好みの言語でチャットしてください！',
    
    // Sidebar
    'new_chat': '新しいチャット',
    'total_messages': 'メッセージ',
    'total_chats': 'チャット',
    
    // Profile
    'guest_user': 'ゲストユーザー',
    'companion': 'BuddyGPT コンパニオン',
    'theme': 'テーマ',
    'light': 'ライト',
    'dark': 'ダーク',
    'language': '言語',
    'advanced_settings': '詳細設定',
    
    // Tools
    'tools': 'ツール',
    'weather': '天気',
    'weather_tool_desc': '現在の天気情報を取得',
    'news': 'ニュース',
    'news_tool_desc': '最新ニュースとヘッドライン',
    'calculator': '電卓',
    'calculator_tool_desc': '高度な数学計算',
    'document_analyzer': 'ドキュメント分析器',
    'document_desc': 'PDFとドキュメントを分析',
    'image_creator': '画像作成者',
    'image_desc': 'AI駆動の画像生成',
    'get_weather': '天気を取得',
    'get_news': 'ニュースを取得',
    'calculate': '計算',
    'enter_city': '都市名を入力...',
    'search_topic': 'トピックを検索（オプション）...',
    'enter_expression': '式を入力（例：2+2*3）...',
    
    // Input
    'message_placeholder': 'BuddyGPTにメッセージを送るか画像を貼り付け (Ctrl+V)... 🌍✨',
    'image_placeholder': 'この画像について聞いてください... 🖼️',
    'open_tools': 'ツールを開く',
    
    // Message Actions
    'copy_message': 'メッセージをコピー',
    'good_response': '良い回答',
    'bad_response': '悪い回答',
    'thanks_feedback': 'ありがとう！👍',
    'feedback_noted': '記録済み 📝',
    
    // Quotes
    'next_quote': '次の引用',
    
    // Scroll
    'back_to_top': 'トップに戻る',
    'loading_messages': 'さらにメッセージを読み込み中...',
    'scroll_load_more': '上にスクロールしてさらに読み込み',
    'conversation_beginning': '会話の始まり',
    
    // Footer
    'footer_desc': '高度なAI技術で会話を強化。あなたの知的なデジタルコンパニオンとチャット、作成、探索',
    'connect_developer': '開発者と接続',
    'made_with': '愛を込めて作成',
    'copyright': '© 2025 BuddyGPT'
  },
  
  ko: {
    // Header
    'buddygpt': 'BuddyGPT',
    'messages': '메시지',
    'active': 'BuddyGPT 활성 ✨',
    'insights': '대화 인사이트 보기',
    'profile': '사용자 프로필',
    
    // Welcome Screen
    'welcome_title': '안녕하세요! 저는 BuddyGPT입니다! 👋',
    'welcome_subtitle': '채팅, 창작 또는 멋진 일을 도울 준비가 되셨나요? ✨',
    'weather_updates': '날씨 업데이트',
    'weather_desc': '모든 위치의 현재 날씨 가져오기',
    'latest_news': '최신 뉴스',
    'news_desc': '속보로 최신 정보 유지',
    'smart_calculator': '스마트 계산기',
    'calculator_desc': '복잡한 수학 문제 해결',
    'multilingual': '🌍 저는 모든 언어를 유창하게 구사합니다 - 선호하는 언어로 채팅하세요!',
    
    // Sidebar
    'new_chat': '새 채팅',
    'total_messages': '메시지',
    'total_chats': '채팅',
    
    // Profile
    'guest_user': '게스트 사용자',
    'companion': 'BuddyGPT 동반자',
    'theme': '테마',
    'light': '밝음',
    'dark': '어둠',
    'language': '언어',
    'advanced_settings': '고급 설정',
    
    // Tools
    'tools': '도구',
    'weather': '날씨',
    'weather_tool_desc': '현재 날씨 정보 가져오기',
    'news': '뉴스',
    'news_tool_desc': '최신 뉴스 및 헤드라인',
    'calculator': '계산기',
    'calculator_tool_desc': '고급 수학 계산',
    'document_analyzer': '문서 분석기',
    'document_desc': 'PDF 및 문서 분석',
    'image_creator': '이미지 생성기',
    'image_desc': 'AI 기반 이미지 생성',
    'get_weather': '날씨 가져오기',
    'get_news': '뉴스 가져오기',
    'calculate': '계산',
    'enter_city': '도시 이름 입력...',
    'search_topic': '주제 검색 (선택사항)...',
    'enter_expression': '식 입력 (예: 2+2*3)...',
    
    // Input
    'message_placeholder': 'BuddyGPT에 메시지를 보내거나 이미지 붙여넣기 (Ctrl+V)... 🌍✨',
    'image_placeholder': '이 이미지에 대해 물어보세요... 🖼️',
    'open_tools': '도구 열기',
    
    // Message Actions
    'copy_message': '메시지 복사',
    'good_response': '좋은 답변',
    'bad_response': '나쁜 답변',
    'thanks_feedback': '감사합니다! 👍',
    'feedback_noted': '기록됨 📝',
    
    // Quotes
    'next_quote': '다음 인용',
    
    // Scroll
    'back_to_top': '맨 위로',
    'loading_messages': '더 많은 메시지 로딩 중...',
    'scroll_load_more': '위로 스크롤하여 더 로드',
    'conversation_beginning': '대화 시작',
    
    // Footer
    'footer_desc': '고급 AI 기술로 대화를 강화합니다. 지능형 디지털 동반자와 채팅, 창작, 탐색',
    'connect_developer': '개발자와 연결',
    'made_with': '사랑으로 제작',
    'copyright': '© 2025 BuddyGPT'
  },
  
  ar: {
    // Header
    'buddygpt': 'BuddyGPT',
    'messages': 'الرسائل',
    'active': 'BuddyGPT نشط ✨',
    'insights': 'عرض رؤى المحادثة',
    'profile': 'الملف الشخصي',
    
    // Welcome Screen
    'welcome_title': 'مرحباً! أنا BuddyGPT! 👋',
    'welcome_subtitle': 'مستعد للدردشة أو الإبداع أو المساعدة في شيء رائع؟ ✨',
    'weather_updates': 'تحديثات الطقس',
    'weather_desc': 'احصل على الطقس الحالي لأي موقع',
    'latest_news': 'آخر الأخبار',
    'news_desc': 'ابق محدثاً مع الأخبار العاجلة',
    'smart_calculator': 'آلة حاسبة ذكية',
    'calculator_desc': 'حل المسائل الرياضية المعقدة',
    'multilingual': '🌍 أتحدث جميع اللغات بطلاقة - تحدث بلغتك المفضلة!',
    
    // Sidebar
    'new_chat': 'محادثة جديدة',
    'total_messages': 'الرسائل',
    'total_chats': 'المحادثات',
    
    // Profile
    'guest_user': 'مستخدم ضيف',
    'companion': 'رفيق BuddyGPT',
    'theme': 'المظهر',
    'light': 'فاتح',
    'dark': 'داكن',
    'language': 'اللغة',
    'advanced_settings': 'الإعدادات المتقدمة',
    
    // Tools
    'tools': 'الأدوات',
    'weather': 'الطقس',
    'weather_tool_desc': 'الحصول على معلومات الطقس الحالية',
    'news': 'الأخبار',
    'news_tool_desc': 'آخر الأخبار والعناوين',
    'calculator': 'آلة حاسبة',
    'calculator_tool_desc': 'حسابات رياضية متقدمة',
    'document_analyzer': 'محلل المستندات',
    'document_desc': 'تحليل ملفات PDF والمستندات',
    'image_creator': 'منشئ الصور',
    'image_desc': 'إنشاء الصور بالذكاء الاصطناعي',
    'get_weather': 'الحصول على الطقس',
    'get_news': 'الحصول على الأخبار',
    'calculate': 'احسب',
    'enter_city': 'أدخل اسم المدينة...',
    'search_topic': 'البحث عن موضوع (اختياري)...',
    'enter_expression': 'أدخل التعبير (مثال: 2+2*3)...',
    
    // Input
    'message_placeholder': 'رسالة إلى BuddyGPT أو الصق صورة (Ctrl+V)... 🌍✨',
    'image_placeholder': 'اسألني عن هذه الصورة... 🖼️',
    'open_tools': 'فتح الأدوات',
    
    // Message Actions
    'copy_message': 'نسخ الرسالة',
    'good_response': 'إجابة جيدة',
    'bad_response': 'إجابة سيئة',
    'thanks_feedback': 'شكراً! 👍',
    'feedback_noted': 'تم التسجيل 📝',
    
    // Quotes
    'next_quote': 'الاقتباس التالي',
    
    // Scroll
    'back_to_top': 'العودة للأعلى',
    'loading_messages': 'تحميل المزيد من الرسائل...',
    'scroll_load_more': 'مرر لأعلى لتحميل المزيد',
    'conversation_beginning': 'بداية المحادثة',
    
    // Footer
    'footer_desc': 'تمكين المحادثات بتقنية الذكاء الاصطناعي المتقدمة. تحدث وأبدع واستكشف مع رفيقك الرقمي الذكي',
    'connect_developer': 'التواصل مع المطور',
    'made_with': 'صنع بـ',
    'copyright': '© 2025 BuddyGPT'
  }
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isIncognitoMode } = useIncognito();
  const [language, setLanguage] = useState<Language>(() => {
    // In incognito mode, don't load from localStorage
    if (isIncognitoMode) return 'en';
    
    const saved = localStorage.getItem('buddygpt-language');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    // Only save to localStorage if not in incognito mode
    if (!isIncognitoMode) {
      localStorage.setItem('buddygpt-language', language);
    }
  }, [language, isIncognitoMode]);

  // Reset to default language when entering incognito mode
  useEffect(() => {
    if (isIncognitoMode) {
      setLanguage('en');
    }
  }, [isIncognitoMode]);

  const t = (key: string): string => {
    return translations[language][key] || translations['en'][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};