import React, { createContext, useContext, useState, useEffect } from 'react';

interface IncognitoContextType {
  isIncognitoMode: boolean;
  toggleIncognitoMode: () => void;
}

const IncognitoContext = createContext<IncognitoContextType | undefined>(undefined);

export const useIncognito = () => {
  const context = useContext(IncognitoContext);
  if (!context) {
    throw new Error('useIncognito must be used within an IncognitoProvider');
  }
  return context;
};

export const IncognitoProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isIncognitoMode, setIsIncognitoMode] = useState(() => {
    // Check if incognito mode was previously enabled (stored in sessionStorage only)
    return sessionStorage.getItem('buddygpt-incognito') === 'true';
  });

  useEffect(() => {
    // Store incognito state in sessionStorage (cleared when browser closes)
    if (isIncognitoMode) {
      sessionStorage.setItem('buddygpt-incognito', 'true');
    } else {
      sessionStorage.removeItem('buddygpt-incognito');
    }
  }, [isIncognitoMode]);

  const toggleIncognitoMode = () => {
    setIsIncognitoMode(prev => !prev);
  };

  return (
    <IncognitoContext.Provider value={{ isIncognitoMode, toggleIncognitoMode }}>
      {children}
    </IncognitoContext.Provider>
  );
};