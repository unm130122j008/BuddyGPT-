interface GeminiMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
}

interface GeminiResponse {
  candidates: {
    content: {
      parts: { text: string }[];
      role: string;
    };
    finishReason: string;
    index: number;
    safetyRatings: any[];
  }[];
  promptFeedback?: {
    safetyRatings: any[];
  };
}

interface GeminiError {
  error: {
    code: number;
    message: string;
    status: string;
  };
}

class GeminiService {
  private apiKey: string;
  private apiUrl: string;
  private model: string;

  constructor() {
    this.apiKey = import.meta.env.VITE_GEMINI_API_KEY || '';
    this.model = import.meta.env.VITE_GEMINI_MODEL || 'gemini-1.5-flash';
    this.apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${this.model}:generateContent`;
    
    // Debug logging
    console.log('🔧 Gemini Service Initialized');
    console.log('📋 API Key:', this.apiKey ? `${this.apiKey.substring(0, 10)}...` : 'NOT SET');
    console.log('🤖 Model:', this.model);
    console.log('🌐 API URL:', this.apiUrl);
  }

  private isDummyKey(): boolean {
    const isDummy = !this.apiKey || this.apiKey.includes('dummy') || this.apiKey.length < 20;
    console.log('🔍 Is Dummy Key:', isDummy);
    return isDummy;
  }

  private formatMessages(userMessage: string, conversationHistory: { role: string; content: string }[] = []): GeminiMessage[] {
    const messages: GeminiMessage[] = [];

    // Add conversation history
    conversationHistory.slice(-10).forEach(msg => {
      messages.push({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: msg.content }]
      });
    });

    // Add current user message
    messages.push({
      role: 'user',
      parts: [{ text: userMessage }]
    });

    console.log('💬 Formatted Messages:', messages);
    return messages;
  }

  async generateResponse(userMessage: string, conversationHistory: { role: string; content: string }[] = []): Promise<string> {
    console.log('🚀 Starting Gemini API Request');
    console.log('📝 User Message:', userMessage);
    
    if (this.isDummyKey()) {
      console.log('⚠️ Using dummy key, returning demo response');
      return this.generateDummyResponse(userMessage);
    }

    try {
      const messages = this.formatMessages(userMessage, conversationHistory);
      
      // For Gemini, we need to format the request differently
      const requestBody = {
        contents: messages,
        generationConfig: {
          temperature: 0.7,
          topK: 40,
          topP: 0.95,
          maxOutputTokens: 1024,
        },
        safetySettings: [
          {
            category: "HARM_CATEGORY_HARASSMENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          },
          {
            category: "HARM_CATEGORY_HATE_SPEECH",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          },
          {
            category: "HARM_CATEGORY_SEXUALLY_EXPLICIT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          },
          {
            category: "HARM_CATEGORY_DANGEROUS_CONTENT",
            threshold: "BLOCK_MEDIUM_AND_ABOVE"
          }
        ]
      };

      console.log('📤 Request Body:', JSON.stringify(requestBody, null, 2));
      console.log('🌐 Making request to:', `${this.apiUrl}?key=${this.apiKey.substring(0, 10)}...`);

      const response = await fetch(`${this.apiUrl}?key=${this.apiKey}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      console.log('📥 Response Status:', response.status);
      console.log('📥 Response Headers:', Object.fromEntries(response.headers.entries()));

      if (!response.ok) {
        let errorMessage = 'Unknown API error occurred';
        let errorDetails = '';
        
        try {
          const errorData: GeminiError = await response.json();
          errorMessage = errorData.error.message;
          errorDetails = JSON.stringify(errorData, null, 2);
          console.error('❌ API Error Response:', errorDetails);
        } catch (parseError) {
          errorMessage = response.statusText || `HTTP ${response.status} error`;
          console.error('❌ Failed to parse error response:', parseError);
        }

        // Handle specific error types
        if (errorMessage.toLowerCase().includes('api key') || response.status === 401) {
          return `❌ **API Key Issue**

There's a problem with your Gemini API key. Please check:

1. **Verify Key**: Go to https://makersuite.google.com/app/apikey
2. **Check Status**: Ensure the key is active and not restricted
3. **Permissions**: Make sure it has access to Gemini API
4. **Regenerate**: Try creating a new API key if needed

**Current Error**: ${errorMessage}
**Status Code**: ${response.status}`;
        }

        if (response.status === 429) {
          return `⏰ **Rate Limit Exceeded**

Too many requests! Gemini free tier limits:
- **15 requests per minute**
- **1,500 requests per day** 
- **1 million tokens per month**

Please wait a moment and try again.`;
        }

        if (errorMessage.toLowerCase().includes('quota')) {
          return `📊 **Quota Exceeded**

Your Gemini API quota has been exceeded:

• **Free Tier**: 15 requests/minute, 1,500/day, 1M tokens/month
• **Check Usage**: Visit https://makersuite.google.com/
• **Wait**: Quotas reset daily/monthly
• **Upgrade**: Consider paid tier for higher limits

**Error**: ${errorMessage}`;
        }

        return `❌ **API Error**

**Status**: ${response.status}
**Message**: ${errorMessage}

Please check your API key and try again.`;
      }

      const data: GeminiResponse = await response.json();
      console.log('✅ API Response:', JSON.stringify(data, null, 2));
      
      if (!data.candidates || data.candidates.length === 0) {
        console.error('❌ No candidates in response');
        return 'I apologize, but no response was generated. Please try rephrasing your question.';
      }

      const candidate = data.candidates[0];
      if (!candidate.content || !candidate.content.parts || candidate.content.parts.length === 0) {
        console.error('❌ Empty content in response');
        return 'I apologize, but the response was empty. Please try again.';
      }

      const responseText = candidate.content.parts[0].text.trim();
      console.log('✅ Generated Response:', responseText);
      return responseText;
    } catch (error) {
      console.error('❌ Gemini API Error:', error);
      
      // Handle network errors
      if (error instanceof TypeError && error.message.includes('fetch')) {
        return `🌐 **Connection Error**

Cannot connect to Gemini API. Please check:
- **Internet Connection**: Ensure you're online
- **Firewall**: Check if API calls are blocked
- **VPN**: Try disabling VPN if active
- **Network**: Try a different network

**Error**: ${error.message}`;
      }
      
      return `❌ **Unexpected Error**

Something went wrong while processing your request:

**Error**: ${error instanceof Error ? error.message : 'Unknown error'}

Please try again or contact support if the issue persists.`;
    }
  }

  private async generateDummyResponse(userMessage: string): Promise<string> {
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

    const responses = [
      `I understand you're asking about "${userMessage.slice(0, 50)}...". This is a demo response since you're using a dummy API key. Get your free Gemini API key at https://makersuite.google.com/app/apikey to enable real AI responses!`,
      
      `That's an interesting question about "${userMessage.slice(0, 30)}...". Currently in demo mode with a dummy API key. Google Gemini offers a generous free tier - get your key at https://makersuite.google.com/app/apikey`,
      
      `I'd be happy to help with that! However, I'm currently using simulated responses because a dummy API key is configured. For real AI-powered conversations with Google Gemini, get your free API key at https://makersuite.google.com/app/apikey`,
      
      `Great question! I'm currently in demonstration mode. Google Gemini has an excellent free tier with 1 million tokens per month. Get started at https://makersuite.google.com/app/apikey`,
    ];

    return responses[Math.floor(Math.random() * responses.length)];
  }

  getApiStatus(): { isConfigured: boolean; message: string } {
    if (this.isDummyKey()) {
      return {
        isConfigured: false,
        message: 'Get free Gemini API key at makersuite.google.com'
      };
    }

    return {
      isConfigured: true,
      message: 'Google Gemini API configured (Free: 1M tokens/month)'
    };
  }

  // Test API connection
  async testConnection(): Promise<{ success: boolean; message: string }> {
    try {
      console.log('🧪 Testing Gemini API connection...');
      const testResponse = await this.generateResponse('Hello, this is a test message.');
      
      if (testResponse.includes('demo response') || testResponse.includes('dummy API key')) {
        return {
          success: false,
          message: 'Using dummy API key - please configure real Gemini API key'
        };
      }
      
      return {
        success: true,
        message: 'Gemini API connection successful!'
      };
    } catch (error) {
      return {
        success: false,
        message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  }
}

export const geminiService = new GeminiService();