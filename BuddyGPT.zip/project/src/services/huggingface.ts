interface HuggingFaceMessage {
  role: 'user' | 'assistant';
  content: string;
}

interface HuggingFaceResponse {
  generated_text?: string;
  error?: string;
}

class HuggingFaceService {
  private apiKey: string;
  private apiUrl: string;
  private model: string;

  constructor() {
    this.apiKey = import.meta.env.VITE_HUGGINGFACE_API_KEY || '';
    this.model = import.meta.env.VITE_HUGGINGFACE_MODEL || 'microsoft/DialoGPT-large';
    this.apiUrl = `https://api-inference.huggingface.co/models/${this.model}`;
  }

  private isDummyKey(): boolean {
    return !this.apiKey || this.apiKey.includes('dummy') || this.apiKey.length < 10;
  }

  async generateResponse(userMessage: string, conversationHistory: HuggingFaceMessage[] = []): Promise<string> {
    if (this.isDummyKey()) {
      return this.generateDummyResponse(userMessage);
    }

    try {
      // Format conversation for the model
      let prompt = '';
      
      // Add conversation history
      conversationHistory.slice(-5).forEach(msg => {
        if (msg.role === 'user') {
          prompt += `Human: ${msg.content}\n`;
        } else {
          prompt += `Assistant: ${msg.content}\n`;
        }
      });
      
      // Add current message
      prompt += `Human: ${userMessage}\nAssistant:`;

      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          inputs: prompt,
          parameters: {
            max_new_tokens: 150,
            temperature: 0.7,
            do_sample: true,
            return_full_text: false
          }
        }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('HuggingFace API Error:', errorText);
        
        if (response.status === 401) {
          return 'Invalid API key. Please check your Hugging Face API key in the .env file.';
        }
        
        if (response.status === 429) {
          return 'Rate limit exceeded. Please wait a moment and try again.';
        }
        
        return `API Error: ${response.status}. Please try again later.`;
      }

      const data = await response.json();
      
      if (Array.isArray(data) && data[0]?.generated_text) {
        return data[0].generated_text.trim();
      }
      
      if (data.error) {
        return `Model Error: ${data.error}`;
      }
      
      return 'No response generated. Please try again.';
      
    } catch (error) {
      console.error('HuggingFace Service Error:', error);
      return 'Connection error. Please check your internet connection and try again.';
    }
  }

  private async generateDummyResponse(userMessage: string): Promise<string> {
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

    const responses = [
      `I understand you're asking about "${userMessage.slice(0, 50)}...". This is a demo response. Add your Hugging Face API key to get real AI responses!`,
      `That's interesting! Currently using demo mode. Get a free Hugging Face API key at https://huggingface.co/settings/tokens to enable real AI chat.`,
      `Great question! I'm in demo mode right now. Sign up at Hugging Face (free) and add your API key to unlock full AI functionality.`,
    ];

    return responses[Math.floor(Math.random() * responses.length)];
  }

  getApiStatus(): { isConfigured: boolean; message: string } {
    if (this.isDummyKey()) {
      return {
        isConfigured: false,
        message: 'Add free Hugging Face API key to enable AI responses'
      };
    }

    return {
      isConfigured: true,
      message: 'Hugging Face API configured (Free tier)'
    };
  }
}

export const huggingFaceService = new HuggingFaceService();