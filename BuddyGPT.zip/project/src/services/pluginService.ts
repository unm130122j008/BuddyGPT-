import { evaluate } from 'mathjs';
import { WeatherData, CalculatorResult } from '../types';

class PluginService {
  // AccuWeather Integration
  async getWeather(location: string): Promise<WeatherData> {
    try {
      // Using AccuWeather API via environment variable
      const API_KEY = import.meta.env.VITE_WEATHER_API_KEY;
      
      // If no API key is configured or it's set to 'demo', use demo data
      if (!API_KEY || API_KEY === 'demo' || API_KEY.trim() === '') {
        console.log('🌤️ Using demo weather data - configure AccuWeather API key for real data');
        return this.getDemoWeather(location);
      }

      console.log('🌤️ Attempting to fetch weather data from AccuWeather API');

      // First, get location key from AccuWeather
      const locationResponse = await fetch(
        `https://dataservice.accuweather.com/locations/v1/cities/search?apikey=${API_KEY}&q=${encodeURIComponent(location)}`,
        {
          method: 'GET',
          headers: {
            'Accept': 'application/json'
          }
        }
      );

      if (!locationResponse.ok) {
        console.warn('AccuWeather location API failed, using demo data. Status:', locationResponse.status);
        return this.getDemoWeather(location);
      }

      const locationData = await locationResponse.json();
      
      if (!locationData || locationData.length === 0) {
        console.warn('Location not found, using demo data');
        return this.getDemoWeather(location);
      }

      const locationKey = locationData[0].Key;
      const locationName = `${locationData[0].LocalizedName}, ${locationData[0].Country.LocalizedName}`;

      // Get current weather conditions
      const weatherResponse = await fetch(
        `https://dataservice.accuweather.com/currentconditions/v1/${locationKey}?apikey=${API_KEY}&details=true`,
        {
          method: 'GET',
          headers: {
            'Accept': 'application/json'
          }
        }
      );

      if (!weatherResponse.ok) {
        console.warn('AccuWeather conditions API failed, using demo data. Status:', weatherResponse.status);
        return this.getDemoWeather(location);
      }

      const weatherData = await weatherResponse.json();
      
      if (!weatherData || weatherData.length === 0) {
        return this.getDemoWeather(location);
      }

      const current = weatherData[0];
      
      console.log('✅ Successfully fetched weather data from AccuWeather');
      
      return {
        location: locationName,
        temperature: Math.round(current.Temperature.Metric.Value),
        condition: current.WeatherText,
        humidity: current.RelativeHumidity || 0,
        windSpeed: Math.round(current.Wind.Speed.Metric.Value),
        icon: current.WeatherIcon.toString().padStart(2, '0')
      };
    } catch (error) {
      console.warn('AccuWeather API Error, falling back to demo data:', error);
      return this.getDemoWeather(location);
    }
  }

  private getDemoWeather(location: string): WeatherData {
    const conditions = ['Sunny', 'Partly Cloudy', 'Cloudy', 'Light Rain', 'Clear Sky'];
    const temps = [18, 22, 25, 28, 15, 20, 24, 26];
    
    return {
      location: location || 'Demo City',
      temperature: temps[Math.floor(Math.random() * temps.length)],
      condition: conditions[Math.floor(Math.random() * conditions.length)],
      humidity: Math.floor(Math.random() * 40) + 40,
      windSpeed: Math.floor(Math.random() * 15) + 5,
      icon: '01'
    };
  }

  // Enhanced Calculator Plugin
  calculate(expression: string): CalculatorResult {
    try {
      // Clean and normalize the expression
      const cleanExpression = expression
        .replace(/[×]/g, '*')
        .replace(/[÷]/g, '/')
        .replace(/[−]/g, '-')
        .replace(/[²]/g, '^2')
        .replace(/[³]/g, '^3')
        .replace(/\s+/g, '') // Remove spaces
        .replace(/,/g, '.'); // Replace commas with dots for decimals

      // Validate expression (basic security check)
      if (!/^[0-9+\-*/^().\s]+$/.test(cleanExpression)) {
        throw new Error('Invalid characters in expression');
      }

      const result = evaluate(cleanExpression);
      
      return {
        expression: expression,
        result: typeof result === 'number' ? this.formatNumber(result) : result.toString(),
        steps: this.getCalculationSteps(cleanExpression, result)
      };
    } catch (error) {
      console.error('Calculator error:', error);
      return {
        expression: expression,
        result: 'Error: Invalid mathematical expression',
        steps: [
          'Please check your expression and try again.',
          'Supported operations: +, -, *, /, ^, (), decimals',
          'Example: 2 + 3 * 4 = 14'
        ]
      };
    }
  }

  private formatNumber(num: number): string {
    if (Number.isInteger(num)) {
      return num.toLocaleString();
    }
    
    // Round to avoid floating point precision issues
    const rounded = Math.round(num * 1000000000) / 1000000000;
    
    // Format with appropriate decimal places
    if (Math.abs(rounded) >= 1000000) {
      return rounded.toExponential(3);
    } else if (Math.abs(rounded) < 0.001 && rounded !== 0) {
      return rounded.toExponential(3);
    } else {
      return parseFloat(rounded.toFixed(6)).toString();
    }
  }

  private getCalculationSteps(expression: string, result: any): string[] {
    const steps = [];
    
    // Analyze the expression type
    if (expression.includes('^')) {
      steps.push(`🔢 Exponentiation: ${expression}`);
      steps.push(`📊 Calculate powers first (order of operations)`);
    } else if (expression.includes('*') || expression.includes('/')) {
      steps.push(`🔢 Expression: ${expression}`);
      steps.push(`📊 Multiplication/Division performed first`);
    } else if (expression.includes('+') || expression.includes('-')) {
      steps.push(`🔢 Expression: ${expression}`);
      steps.push(`📊 Addition/Subtraction calculation`);
    } else {
      steps.push(`🔢 Simple calculation: ${expression}`);
    }
    
    steps.push(`✅ Final Result: ${result}`);
    
    // Add helpful context
    if (typeof result === 'number') {
      if (result > 1000000) {
        steps.push(`💡 That's ${(result / 1000000).toFixed(2)} million!`);
      } else if (result < 0.001 && result > 0) {
        steps.push(`💡 Very small number - shown in scientific notation`);
      }
    }
    
    return steps;
  }

  // Enhanced Plugin Detection
  detectPlugin(message: string): { type: 'weather' | 'calculator' | null; params: any } {
    const lowerMessage = message.toLowerCase();
    
    // Weather detection with better patterns
    const weatherKeywords = ['weather', 'temperature', 'forecast', 'climate', 'rain', 'sunny', 'cloudy', 'hot', 'cold', 'humidity', 'wind'];
    const weatherPhrases = ['what\'s the weather', 'how\'s the weather', 'weather in', 'temperature in', 'forecast for'];
    
    if (weatherKeywords.some(keyword => lowerMessage.includes(keyword)) || 
        weatherPhrases.some(phrase => lowerMessage.includes(phrase))) {
      
      // Extract location with improved regex
      const locationPatterns = [
        /(?:weather|temperature|forecast).*?(?:in|for|at)\s+([a-zA-Z\s,.-]+?)(?:\?|$|\.)/i,
        /(?:in|for|at)\s+([a-zA-Z\s,.-]+?)(?:\s+weather|\s+temperature|\?|$|\.)/i,
        /([a-zA-Z\s,.-]+?)(?:\s+weather|\s+temperature|\s+forecast)/i
      ];
      
      let location = 'current location';
      for (const pattern of locationPatterns) {
        const match = message.match(pattern);
        if (match && match[1]) {
          location = match[1].trim();
          break;
        }
      }
      
      return { type: 'weather', params: { location } };
    }

    // Enhanced calculator detection
    const mathPattern = /[\d+\-*/^().\s×÷−²³=]+/;
    const hasNumbers = /\d/.test(message);
    const hasMathOperators = /[+\-*/^×÷−²³=]/.test(message);
    const mathKeywords = ['calculate', 'compute', 'solve', 'math', 'equals', 'what is', 'how much is'];
    const mathPhrases = ['what is', 'how much is', 'calculate', 'solve for'];
    
    if ((hasNumbers && hasMathOperators) || 
        mathKeywords.some(keyword => lowerMessage.includes(keyword)) ||
        mathPhrases.some(phrase => lowerMessage.includes(phrase))) {
      
      // Extract mathematical expression with improved logic
      let expression = message;
      
      // Try to extract just the mathematical part
      const mathMatch = message.match(/[\d+\-*/^().\s×÷−²³=]+/g);
      if (mathMatch) {
        expression = mathMatch.join(' ').trim();
      }
      
      // Clean up common phrases
      expression = expression
        .replace(/what\s+is\s+/gi, '')
        .replace(/how\s+much\s+is\s+/gi, '')
        .replace(/calculate\s+/gi, '')
        .replace(/solve\s+/gi, '')
        .replace(/equals?\s*/gi, '')
        .replace(/\?+/g, '')
        .trim();
      
      return { type: 'calculator', params: { expression } };
    }

    return { type: null, params: {} };
  }

  // Test tools functionality
  async testAllTools(): Promise<{ weather: boolean; calculator: boolean }> {
    const results = {
      weather: false,
      calculator: false
    };

    try {
      // Test weather
      const weatherResult = await this.getWeather('London');
      results.weather = weatherResult && weatherResult.location && weatherResult.temperature !== undefined;
    } catch (error) {
      console.error('Weather test failed:', error);
    }

    try {
      // Test calculator
      const calcResult = this.calculate('2 + 2');
      results.calculator = calcResult && calcResult.result === '4';
    } catch (error) {
      console.error('Calculator test failed:', error);
    }

    return results;
  }
}

export const pluginService = new PluginService();