class FileAnalysisService {
  // Enhanced file reading and analysis service
  async analyzeFile(file: File): Promise<{
    content: string;
    metadata: any;
    analysis: string;
  }> {
    const fileType = this.getFileType(file);
    
    try {
      switch (fileType) {
        case 'image':
          return await this.analyzeImage(file);
        case 'pdf':
          return await this.analyzePDF(file);
        case 'document':
          return await this.analyzeDocument(file);
        case 'spreadsheet':
          return await this.analyzeSpreadsheet(file);
        case 'text':
          return await this.analyzeTextFile(file);
        default:
          return await this.analyzeGenericFile(file);
      }
    } catch (error) {
      console.error('File analysis error:', error);
      return {
        content: '',
        metadata: { error: 'Failed to analyze file' },
        analysis: 'Unable to analyze this file. Please try again or use a different file format.'
      };
    }
  }

  private getFileType(file: File): string {
    if (file.type.startsWith('image/')) return 'image';
    if (file.type === 'application/pdf') return 'pdf';
    if (file.type.includes('word') || file.type.includes('document')) return 'document';
    if (file.type.includes('excel') || file.type.includes('sheet')) return 'spreadsheet';
    if (file.type.includes('powerpoint') || file.type.includes('presentation')) return 'presentation';
    if (file.type.startsWith('text/') || file.type === 'application/json') return 'text';
    return 'generic';
  }

  private async analyzeImage(file: File): Promise<any> {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          canvas.width = img.width;
          canvas.height = img.height;
          ctx?.drawImage(img, 0, 0);
          
          // Extract image metadata and basic analysis
          const metadata = {
            width: img.width,
            height: img.height,
            size: file.size,
            type: file.type,
            aspectRatio: (img.width / img.height).toFixed(2),
            megapixels: ((img.width * img.height) / 1000000).toFixed(1)
          };
          
          resolve({
            content: e.target?.result as string,
            metadata,
            analysis: `Image successfully loaded for AI analysis. Dimensions: ${img.width}x${img.height} pixels (${metadata.megapixels}MP)`
          });
        };
        img.src = e.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  }

  private async analyzePDF(file: File): Promise<any> {
    // For PDF analysis, we'll provide metadata and let the AI handle content extraction
    const metadata = {
      size: file.size,
      type: file.type,
      name: file.name,
      lastModified: new Date(file.lastModified),
      pages: 'Unknown (will be analyzed by AI)'
    };

    return {
      content: 'PDF file ready for AI analysis',
      metadata,
      analysis: `PDF document "${file.name}" (${(file.size / 1024 / 1024).toFixed(2)}MB) is ready for comprehensive analysis.`
    };
  }

  private async analyzeDocument(file: File): Promise<any> {
    const metadata = {
      size: file.size,
      type: file.type,
      name: file.name,
      lastModified: new Date(file.lastModified),
      format: file.type.includes('word') ? 'Microsoft Word' : 'Document'
    };

    return {
      content: 'Document file ready for AI analysis',
      metadata,
      analysis: `${metadata.format} document "${file.name}" (${(file.size / 1024 / 1024).toFixed(2)}MB) is ready for analysis.`
    };
  }

  private async analyzeSpreadsheet(file: File): Promise<any> {
    const metadata = {
      size: file.size,
      type: file.type,
      name: file.name,
      lastModified: new Date(file.lastModified),
      format: file.type.includes('excel') ? 'Microsoft Excel' : 'Spreadsheet'
    };

    return {
      content: 'Spreadsheet file ready for AI analysis',
      metadata,
      analysis: `${metadata.format} file "${file.name}" (${(file.size / 1024 / 1024).toFixed(2)}MB) is ready for data analysis.`
    };
  }

  private async analyzeTextFile(file: File): Promise<any> {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const content = e.target?.result as string;
        const lines = content.split('\n').length;
        const words = content.split(/\s+/).length;
        const characters = content.length;
        
        const metadata = {
          size: file.size,
          type: file.type,
          name: file.name,
          lines,
          words,
          characters,
          encoding: 'UTF-8'
        };

        resolve({
          content,
          metadata,
          analysis: `Text file analyzed: ${lines} lines, ${words} words, ${characters} characters.`
        });
      };
      reader.readAsText(file);
    });
  }

  private async analyzeGenericFile(file: File): Promise<any> {
    const metadata = {
      size: file.size,
      type: file.type,
      name: file.name,
      lastModified: new Date(file.lastModified)
    };

    return {
      content: 'File ready for AI analysis',
      metadata,
      analysis: `File "${file.name}" (${file.type}, ${(file.size / 1024 / 1024).toFixed(2)}MB) is ready for analysis.`
    };
  }
}

export const fileAnalysisService = new FileAnalysisService();