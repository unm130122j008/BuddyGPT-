interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface OpenAIResponse {
  choices: {
    message: {
      content: string;
      role: string;
    };
    finish_reason: string;
  }[];
  usage: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
}

interface OpenAIError {
  error: {
    message: string;
    type: string;
    code?: string;
  };
}

class OpenAIService {
  private apiKey: string;
  private apiUrl: string;
  private model: string;
  private maxTokens: number;
  private temperature: number;

  constructor() {
    this.apiKey = import.meta.env.VITE_OPENAI_API_KEY || '';
    this.apiUrl = import.meta.env.VITE_OPENAI_API_URL || 'https://api.openai.com/v1/chat/completions';
    this.model = import.meta.env.VITE_OPENAI_MODEL || 'gpt-3.5-turbo';
    this.maxTokens = parseInt(import.meta.env.VITE_MAX_TOKENS || '1000');
    this.temperature = parseFloat(import.meta.env.VITE_TEMPERATURE || '0.7');
  }

  private isDummyKey(): boolean {
    return !this.apiKey || this.apiKey.includes('dummy') || this.apiKey.length < 20;
  }

  private formatMessages(userMessage: string, conversationHistory: OpenAIMessage[] = []): OpenAIMessage[] {
    const systemMessage: OpenAIMessage = {
      role: 'system',
      content: 'You are a helpful AI assistant. Provide clear, concise, and helpful responses to user questions. Be friendly and professional in your communication.'
    };

    // Include recent conversation history (last 10 messages to manage token usage)
    const recentHistory = conversationHistory.slice(-10);
    
    return [
      systemMessage,
      ...recentHistory,
      {
        role: 'user',
        content: userMessage
      }
    ];
  }

  async generateResponse(
    userMessage: string, 
    conversationHistory: OpenAIMessage[] = []
  ): Promise<string> {
    // If using dummy key, return simulated response
    if (this.isDummyKey()) {
      return this.generateDummyResponse(userMessage);
    }

    try {
      const messages = this.formatMessages(userMessage, conversationHistory);

      const response = await fetch(this.apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: this.model,
          messages,
          max_tokens: this.maxTokens,
          temperature: this.temperature,
          stream: false,
        }),
      });

      if (!response.ok) {
        let errorMessage = 'Unknown API error occurred';
        
        try {
          const errorData: OpenAIError = await response.json();
          errorMessage = errorData.error.message;
        } catch (parseError) {
          // If we can't parse the error response, use the status text
          errorMessage = response.statusText || `HTTP ${response.status} error`;
        }

        // Handle specific error types with user-friendly messages
        if (errorMessage.toLowerCase().includes('quota') || errorMessage.toLowerCase().includes('billing')) {
          return `I apologize, but your OpenAI API quota has been exceeded. To continue using the AI chat:

1. Visit https://platform.openai.com/account/billing
2. Check your current usage and billing details
3. Add credits to your account or upgrade your plan
4. Ensure your payment method is up to date

Your API key is valid, but needs more credits to continue making requests.`;
        }

        if (errorMessage.toLowerCase().includes('rate limit')) {
          return 'I apologize, but too many requests have been made recently. Please wait a moment and try again.';
        }

        if (errorMessage.toLowerCase().includes('api key') || errorMessage.toLowerCase().includes('unauthorized')) {
          return `I apologize, but there seems to be an issue with your API key. Please:

1. Check that your VITE_OPENAI_API_KEY in the .env file is correct
2. Ensure the API key is active at https://platform.openai.com/api-keys
3. Verify the key has the necessary permissions

Current error: ${errorMessage}`;
        }

        // For any other API errors, show the specific message
        return `I encountered an API error: ${errorMessage}. Please check your OpenAI account status and try again.`;
      }

      const data: OpenAIResponse = await response.json();
      
      if (!data.choices || data.choices.length === 0) {
        return 'I apologize, but no response was generated. Please try rephrasing your question.';
      }

      return data.choices[0].message.content.trim();
    } catch (error) {
      console.error('OpenAI API Error:', error);
      
      // Handle network errors
      if (error instanceof TypeError && error.message.includes('fetch')) {
        return 'I apologize, but I cannot connect to the OpenAI API. Please check your internet connection and try again.';
      }
      
      // Handle any other unexpected errors
      return 'I apologize, but I encountered an unexpected error while processing your request. Please try again later.';
    }
  }

  private async generateDummyResponse(userMessage: string): Promise<string> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));

    const responses = [
      `I understand you're asking about "${userMessage.slice(0, 50)}...". This is a simulated response since you're using a dummy API key. Replace the VITE_OPENAI_API_KEY in your .env file with your actual OpenAI API key to get real AI responses.`,
      
      `That's an interesting question about "${userMessage.slice(0, 30)}...". Currently, I'm running in demo mode with a dummy API key. To enable full AI functionality, please update your .env file with a valid OpenAI API key.`,
      
      `I'd be happy to help with that! However, I'm currently using simulated responses because a dummy API key is configured. For real AI-powered conversations, please replace the dummy key in your .env file with your actual OpenAI API key.`,
      
      `Great question! I'm currently in demonstration mode since you're using a placeholder API key. To unlock the full potential of this AI chat application, simply replace the dummy API key in your .env file with your real OpenAI API key.`,
    ];

    return responses[Math.floor(Math.random() * responses.length)];
  }

  getApiStatus(): { isConfigured: boolean; message: string } {
    if (this.isDummyKey()) {
      return {
        isConfigured: false,
        message: 'Using dummy API key. Replace with actual OpenAI API key to enable AI responses.'
      };
    }

    return {
      isConfigured: true,
      message: 'OpenAI API is properly configured.'
    };
  }
}

export const openAIService = new OpenAIService();