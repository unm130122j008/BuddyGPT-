interface ImageGenerationRequest {
  prompt: string;
  model?: string;
  size?: string;
  quality?: string;
  style?: string;
}

interface ImageGenerationResponse {
  success: boolean;
  imageUrl?: string;
  error?: string;
}

class ImageService {
  private apiKey: string;
  private baseUrl: string;

  constructor() {
    // Load API key from environment variable
    this.apiKey = import.meta.env.VITE_OPENAI_IMAGE_API_KEY || '';
    this.baseUrl = 'https://api.openai.com/v1/images/generations';
  }

  async generateImage(request: ImageGenerationRequest): Promise<ImageGenerationResponse> {
    try {
      // Check if API key is configured
      if (!this.apiKey || this.apiKey.trim() === '') {
        console.warn('🎨 OpenAI Image API key not configured');
        return {
          success: false,
          error: 'Image generation is not configured. Please add your OpenAI API key to the environment variables as VITE_OPENAI_IMAGE_API_KEY to enable image generation.'
        };
      }

      console.log('🎨 Generating image with prompt:', request.prompt);
      
      const response = await fetch(this.baseUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: request.model || 'dall-e-3',
          prompt: this.enhancePrompt(request.prompt),
          n: 1,
          size: request.size || '1024x1024',
          quality: request.quality || 'hd',
          style: request.style || 'vivid'
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('Image Generation API Error:', response.status, errorData);
        
        if (response.status === 401) {
          return {
            success: false,
            error: 'Authentication failed. Please check your OpenAI API key configuration in the environment variables (VITE_OPENAI_IMAGE_API_KEY).'
          };
        }
        
        if (response.status === 429) {
          return {
            success: false,
            error: 'Rate limit exceeded. Please wait a moment and try again.'
          };
        }
        
        if (response.status === 400) {
          const errorMsg = errorData.error?.message || 'Invalid request parameters';
          return {
            success: false,
            error: `Request error: ${errorMsg}. Please try a different prompt.`
          };
        }
        
        return {
          success: false,
          error: `Image generation failed: ${errorData.error?.message || 'Unknown error'}`
        };
      }

      const data = await response.json();
      console.log('✅ Image generation successful');
      
      if (data.data && data.data.length > 0) {
        return {
          success: true,
          imageUrl: data.data[0].url
        };
      }
      
      return {
        success: false,
        error: 'No image was generated. Please try again with a different prompt.'
      };
      
    } catch (error) {
      console.error('Image Service Error:', error);
      return {
        success: false,
        error: 'Network error. Please check your connection and try again.'
      };
    }
  }

  // Enhanced prompt engineering for better image generation
  private enhancePrompt(originalPrompt: string): string {
    // Don't enhance if prompt is already detailed (>50 characters)
    if (originalPrompt.length > 50) {
      return originalPrompt;
    }

    // Add artistic enhancements for simple prompts
    const enhancements = [
      'high quality, detailed, professional photography',
      'beautiful lighting, sharp focus, vibrant colors',
      'artistic composition, stunning visual',
      'masterpiece quality, ultra-detailed',
      'photorealistic, high resolution'
    ];

    const randomEnhancement = enhancements[Math.floor(Math.random() * enhancements.length)];
    return `${originalPrompt}, ${randomEnhancement}`;
  }

  // Improved image generation request detection
  isImageGenerationRequest(message: string): boolean {
    const imageKeywords = [
      'generate image', 'create image', 'make image', 'draw', 'paint',
      'generate picture', 'create picture', 'make picture',
      'show me', 'visualize', 'illustrate', 'design',
      'generate art', 'create art', 'make art',
      'dall-e', 'dalle', 'ai image', 'ai art'
    ];
    
    const imagePhrases = [
      'can you draw', 'can you create', 'can you generate',
      'i want an image', 'i need an image', 'make me an image',
      'create an image', 'generate an image'
    ];
    
    const lowerMessage = message.toLowerCase();
    
    return imageKeywords.some(keyword => lowerMessage.includes(keyword)) ||
           imagePhrases.some(phrase => lowerMessage.includes(phrase));
  }

  // Enhanced prompt extraction
  extractImagePrompt(message: string): string {
    const lowerMessage = message.toLowerCase();
    
    // Remove common prefixes with improved regex
    const prefixes = [
      /^(?:generate|create|make|draw|paint)\s+(?:an?\s+)?(?:image|picture|art)\s+(?:of\s+)?/i,
      /^(?:show\s+me|visualize|illustrate|design)\s+(?:an?\s+)?/i,
      /^(?:can\s+you\s+)?(?:generate|create|make|draw)\s+(?:me\s+)?(?:an?\s+)?(?:image|picture)\s+(?:of\s+)?/i,
      /^(?:i\s+(?:want|need)\s+(?:an?\s+)?(?:image|picture)\s+(?:of\s+)?)/i,
      /^(?:dall-?e|ai)\s+/i
    ];
    
    let cleanPrompt = message;
    
    for (const prefix of prefixes) {
      cleanPrompt = cleanPrompt.replace(prefix, '').trim();
    }
    
    // Remove trailing punctuation
    cleanPrompt = cleanPrompt.replace(/[.!?]+$/, '').trim();
    
    return cleanPrompt || message;
  }

  // Test image generation functionality
  async testImageGeneration(): Promise<boolean> {
    try {
      // If no API key is configured, return false
      if (!this.apiKey || this.apiKey.trim() === '') {
        console.log('Image generation test skipped - no API key configured');
        return false;
      }

      const testResult = await this.generateImage({
        prompt: 'a simple red circle',
        size: '256x256',
        quality: 'standard'
      });
      return testResult.success;
    } catch (error) {
      console.error('Image generation test failed:', error);
      return false;
    }
  }
}

export const imageService = new ImageService();