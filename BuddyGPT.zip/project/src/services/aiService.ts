import { openAIService } from './openai';
import { huggingFaceService } from './huggingface';
import { geminiService } from './gemini';

// AI Service selector - automatically chooses the best available service
class AIService {
  private currentProvider: 'openai' | 'gemini' | 'huggingface' = 'gemini'; // Default to Gemini (best free option)

  constructor() {
    // Auto-detect which service to use based on available API keys
    this.detectBestProvider();
  }

  private detectBestProvider() {
    const openAIStatus = openAIService.getApiStatus();
    const geminiStatus = geminiService.getApiStatus();
    const hfStatus = huggingFaceService.getApiStatus();

    // Priority: OpenAI (if configured) > Gemini (best free) > HuggingFace (fallback)
    if (openAIStatus.isConfigured) {
      this.currentProvider = 'openai';
    } else if (geminiStatus.isConfigured) {
      this.currentProvider = 'gemini';
    } else if (hfStatus.isConfigured) {
      this.currentProvider = 'huggingface';
    } else {
      // Default to Gemini for demo mode (best free option)
      this.currentProvider = 'gemini';
    }
  }

  async generateResponse(userMessage: string, conversationHistory: any[] = []): Promise<string> {
    this.detectBestProvider(); // Re-check on each request

    try {
      if (this.currentProvider === 'openai') {
        return await openAIService.generateResponse(userMessage, conversationHistory);
      } else if (this.currentProvider === 'gemini') {
        // Convert to Gemini format
        const geminiHistory = conversationHistory.map(msg => ({
          role: msg.role === 'user' ? 'user' : 'assistant',
          content: msg.content
        }));
        return await geminiService.generateResponse(userMessage, geminiHistory);
      } else {
        // HuggingFace fallback
        const hfHistory = conversationHistory.map(msg => ({
          role: msg.role === 'user' ? 'user' as const : 'assistant' as const,
          content: msg.content
        }));
        return await huggingFaceService.generateResponse(userMessage, hfHistory);
      }
    } catch (error) {
      console.error('AI Service Error:', error);
      return 'I apologize, but I encountered an error. Please try again.';
    }
  }

  getApiStatus(): { isConfigured: boolean; message: string; provider: string } {
    this.detectBestProvider();
    
    if (this.currentProvider === 'openai') {
      const status = openAIService.getApiStatus();
      return { ...status, provider: 'OpenAI' };
    } else if (this.currentProvider === 'gemini') {
      const status = geminiService.getApiStatus();
      return { ...status, provider: 'Google Gemini (Free)' };
    } else {
      const status = huggingFaceService.getApiStatus();
      return { ...status, provider: 'Hugging Face (Free)' };
    }
  }

  getCurrentProvider(): string {
    if (this.currentProvider === 'openai') return 'OpenAI';
    if (this.currentProvider === 'gemini') return 'Google Gemini';
    return 'Hugging Face';
  }
}

export const aiService = new AIService();