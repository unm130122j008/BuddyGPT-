import React, { useState } from 'react';
import { User, Settings, Globe, Moon, Sun, Shield, Linkedin, LogOut, Edit3, Home } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useLanguage } from '../contexts/LanguageContext';
import { useIncognito } from '../contexts/IncognitoContext';
import { useAuth } from '../contexts/AuthContext';
import { AdvancedSettings } from './AdvancedSettings';

interface UserProfileProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserProfile: React.FC<UserProfileProps> = ({ isOpen, onClose }) => {
  const { theme, toggleTheme } = useTheme();
  const { language, setLanguage, t } = useLanguage();
  const { isIncognitoMode } = useIncognito();
  const { currentUser, logout, loginWithName } = useAuth();
  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [isEditingName, setIsEditingName] = useState(false);
  const [newName, setNewName] = useState(currentUser?.name || '');

  const languages = [
    { code: 'en' as const, name: 'English', flag: '🇺🇸' },
    { code: 'ta' as const, name: 'தமிழ்', flag: '🇮🇳' },
    { code: 'es' as const, name: 'Español', flag: '🇪🇸' },
    { code: 'fr' as const, name: 'Français', flag: '🇫🇷' },
    { code: 'de' as const, name: 'Deutsch', flag: '🇩🇪' },
    { code: 'zh' as const, name: '中文', flag: '🇨🇳' },
    { code: 'ja' as const, name: '日本語', flag: '🇯🇵' },
    { code: 'ko' as const, name: '한국어', flag: '🇰🇷' },
    { code: 'ar' as const, name: 'العربية', flag: '🇸🇦' }
  ];

  const themeOptions = [
    { value: 'light', label: t('light'), icon: <Sun className="w-4 h-4" /> },
    { value: 'dark', label: t('dark'), icon: <Moon className="w-4 h-4" /> }
  ];

  const handleLogout = async () => {
    try {
      setIsLoggingOut(true);
      await logout();
      onClose();
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setIsLoggingOut(false);
    }
  };

  const handleNameUpdate = async () => {
    if (newName.trim() && newName.trim() !== currentUser?.name) {
      try {
        await loginWithName(newName.trim());
        setIsEditingName(false);
      } catch (error) {
        console.error('Error updating name:', error);
      }
    } else {
      setIsEditingName(false);
      setNewName(currentUser?.name || '');
    }
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/50 z-50" onClick={onClose} />
      <div className="fixed top-16 right-4 w-80 bg-white dark:bg-gray-800 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 z-50 animate-in slide-in-from-top-2 duration-200">
        {/* Profile Header */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              {isIncognitoMode && (
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-purple-600 rounded-full flex items-center justify-center">
                  <Shield className="w-2.5 h-2.5 text-white" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              {isEditingName ? (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    className="w-full px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    onKeyPress={(e) => e.key === 'Enter' && handleNameUpdate()}
                    onBlur={handleNameUpdate}
                    autoFocus
                  />
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100 truncate">
                    {currentUser?.name || 'User'}
                  </h3>
                  <button
                    onClick={() => {
                      setIsEditingName(true);
                      setNewName(currentUser?.name || '');
                    }}
                    className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors"
                    title="Edit name"
                  >
                    <Edit3 className="w-3 h-3 text-gray-500" />
                  </button>
                  {isIncognitoMode && (
                    <span className="ml-2 px-2 py-0.5 bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300 text-xs rounded-full">
                      {t('incognito')}
                    </span>
                  )}
                </div>
              )}
              <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                {currentUser?.email || t('companion')}
              </p>
            </div>
          </div>
        </div>

        {/* Settings */}
        <div className="p-4 space-y-4">
          {/* Theme Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              {t('theme')}
            </label>
            <div className="grid grid-cols-2 gap-2">
              {themeOptions.map((option) => (
                <button
                  key={option.value}
                  onClick={() => option.value !== theme && toggleTheme()}
                  className={`flex items-center gap-2 p-2 rounded-lg border transition-all ${
                    option.value === theme
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                      : 'border-gray-200 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700'
                  }`}
                >
                  {option.icon}
                  <span className="text-xs font-medium">{option.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Language Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              <Globe className="w-4 h-4 inline mr-1" />
              {t('language')}
            </label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as any)}
              className="w-full p-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {languages.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.flag} {lang.name}
                </option>
              ))}
            </select>
          </div>

          {/* Advanced Settings Button */}
          <button 
            onClick={() => setShowAdvancedSettings(true)}
            className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors text-left border border-gray-200 dark:border-gray-600"
          >
            <div className={`p-2 rounded-lg ${isIncognitoMode ? 'bg-purple-100 dark:bg-purple-900/20' : 'bg-gray-100 dark:bg-gray-700'}`}>
              <Shield className={`w-4 h-4 ${isIncognitoMode ? 'text-purple-600 dark:text-purple-400' : 'text-gray-500 dark:text-gray-400'}`} />
            </div>
            <div className="flex-1">
              <span className="text-gray-700 dark:text-gray-300 font-medium">{t('advanced_settings')}</span>
              {isIncognitoMode && (
                <p className="text-xs text-purple-600 dark:text-purple-400 mt-0.5">
                  {t('incognito_mode_active')}
                </p>
              )}
            </div>
          </button>

          {/* Developer Contact */}
          <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
            <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
              Connect with Developer
            </h4>
            <a 
              href="https://www.linkedin.com/in/naveen-c-designer" 
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 p-3 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-colors border border-blue-200 dark:border-blue-700 group"
            >
              <div className="p-2 bg-blue-100 dark:bg-blue-900/20 rounded-lg group-hover:bg-blue-200 dark:group-hover:bg-blue-900/30 transition-colors">
                <Linkedin className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <span className="text-blue-700 dark:text-blue-300 font-medium">
                Connect on LinkedIn
              </span>
            </a>
          </div>

          {/* Sign Out Button */}
          <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
            <button
              onClick={handleLogout}
              disabled={isLoggingOut}
              className="w-full flex items-center justify-center gap-3 p-3 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors border border-red-200 dark:border-red-700 text-red-600 dark:text-red-400 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoggingOut ? (
                <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Home className="w-4 h-4" />
                  <span className="font-medium">
                    Back to Home
                  </span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
            {t('buddygpt')} v2.0 • Enhanced AI Assistant
          </p>
        </div>
      </div>

      {/* Advanced Settings Modal */}
      <AdvancedSettings 
        isOpen={showAdvancedSettings} 
        onClose={() => setShowAdvancedSettings(false)} 
      />
    </>
  );
};