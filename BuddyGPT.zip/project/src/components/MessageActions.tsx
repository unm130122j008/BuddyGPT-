import React, { useState } from 'react';
import { Copy, ThumbsUp, ThumbsDown, Check } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface MessageActionsProps {
  messageContent: string;
  messageId: string;
  onFeedback?: (messageId: string, type: 'like' | 'dislike') => void;
}

export const MessageActions: React.FC<MessageActionsProps> = ({ 
  messageContent, 
  messageId, 
  onFeedback 
}) => {
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState<'like' | 'dislike' | null>(null);
  const { t } = useLanguage();

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(messageContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy text:', error);
    }
  };

  const handleFeedback = (type: 'like' | 'dislike') => {
    setFeedback(type);
    onFeedback?.(messageId, type);
    
    // Show feedback confirmation
    setTimeout(() => {
      if (type === 'like') {
        // Could show a thank you message or improvement suggestion
      } else {
        // Could show feedback form or improvement options
      }
    }, 500);
  };

  return (
    <div className="flex items-center gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
      {/* Copy Button */}
      <button
        onClick={handleCopy}
        className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors duration-200 group/btn"
        title={t('copy_message')}
      >
        {copied ? (
          <Check className="w-4 h-4 text-green-600 dark:text-green-400" />
        ) : (
          <Copy className="w-4 h-4 text-gray-500 dark:text-gray-400 group-hover/btn:text-gray-700 dark:group-hover/btn:text-gray-300" />
        )}
      </button>

      {/* Thumbs Up */}
      <button
        onClick={() => handleFeedback('like')}
        className={`p-2 rounded-lg transition-all duration-200 group/btn ${
          feedback === 'like'
            ? 'bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-400'
            : 'hover:bg-gray-100 dark:hover:bg-gray-700'
        }`}
        title={t('good_response')}
      >
        <ThumbsUp className={`w-4 h-4 transition-colors ${
          feedback === 'like'
            ? 'text-green-600 dark:text-green-400'
            : 'text-gray-500 dark:text-gray-400 group-hover/btn:text-gray-700 dark:group-hover/btn:text-gray-300'
        }`} />
      </button>

      {/* Thumbs Down */}
      <button
        onClick={() => handleFeedback('dislike')}
        className={`p-2 rounded-lg transition-all duration-200 group/btn ${
          feedback === 'dislike'
            ? 'bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400'
            : 'hover:bg-gray-100 dark:hover:bg-gray-700'
        }`}
        title={t('bad_response')}
      >
        <ThumbsDown className={`w-4 h-4 transition-colors ${
          feedback === 'dislike'
            ? 'text-red-600 dark:text-red-400'
            : 'text-gray-500 dark:text-gray-400 group-hover/btn:text-gray-700 dark:group-hover/btn:text-gray-300'
        }`} />
      </button>

      {/* Feedback Status */}
      {feedback && (
        <div className="ml-2 px-2 py-1 rounded-full text-xs font-medium animate-in fade-in duration-300">
          {feedback === 'like' ? (
            <span className="text-green-600 dark:text-green-400 bg-green-100 dark:bg-green-900/20 px-2 py-1 rounded-full">
              {t('thanks_feedback')}
            </span>
          ) : (
            <span className="text-orange-600 dark:text-orange-400 bg-orange-100 dark:bg-orange-900/20 px-2 py-1 rounded-full">
              {t('feedback_noted')}
            </span>
          )}
        </div>
      )}
    </div>
  );
};