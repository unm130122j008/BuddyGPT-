import React from 'react';
import { Sparkles, Video, FileImage, MessageSquare, Calculator, Newspaper } from 'lucide-react';

interface SmartSuggestionsProps {
  lastMessage?: string;
  onSuggestionClick: (suggestion: string) => void;
}

export const SmartSuggestions: React.FC<SmartSuggestionsProps> = ({ 
  lastMessage, 
  onSuggestionClick 
}) => {
  const getSmartSuggestions = (message: string) => {
    const lower = message.toLowerCase();
    
    if (lower.includes('story') || lower.includes('write')) {
      return [
        { text: "Continue this story 📖", icon: <MessageSquare className="w-4 h-4" /> },
        { text: "Turn this into a video script 🎬", icon: <Video className="w-4 h-4" /> },
        { text: "Create a summary ✨", icon: <Sparkles className="w-4 h-4" /> }
      ];
    }
    
    if (lower.includes('image') || lower.includes('picture') || lower.includes('photo')) {
      return [
        { text: "Generate a similar image 🎨", icon: <FileImage className="w-4 h-4" /> },
        { text: "Create variations of this 🔄", icon: <Sparkles className="w-4 h-4" /> },
        { text: "Describe this image 👁️", icon: <MessageSquare className="w-4 h-4" /> }
      ];
    }
    
    if (lower.includes('calculate') || lower.includes('math') || /\d+/.test(message)) {
      return [
        { text: "Show calculation steps 🧮", icon: <Calculator className="w-4 h-4" /> },
        { text: "Solve a similar problem 🔢", icon: <Calculator className="w-4 h-4" /> },
        { text: "Explain the math concept 📚", icon: <MessageSquare className="w-4 h-4" /> }
      ];
    }
    
    if (lower.includes('news') || lower.includes('current') || lower.includes('latest')) {
      return [
        { text: "Get more news on this topic 📰", icon: <Newspaper className="w-4 h-4" /> },
        { text: "Summarize these articles 📝", icon: <MessageSquare className="w-4 h-4" /> },
        { text: "Find related stories 🔍", icon: <Sparkles className="w-4 h-4" /> }
      ];
    }
    
    // Default suggestions
    return [
      { text: "Tell me more about this 🤔", icon: <MessageSquare className="w-4 h-4" /> },
      { text: "Create a summary ✨", icon: <Sparkles className="w-4 h-4" /> },
      { text: "What's next? 🚀", icon: <Sparkles className="w-4 h-4" /> }
    ];
  };

  if (!lastMessage) return null;

  const suggestions = getSmartSuggestions(lastMessage);

  return (
    <div className="flex gap-2 overflow-x-auto pb-2 animate-in slide-in-from-bottom-2 duration-300">
      {suggestions.map((suggestion, index) => (
        <button
          key={index}
          onClick={() => onSuggestionClick(suggestion.text.replace(/[^\w\s]/g, '').trim())}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-50 to-purple-50 hover:from-blue-100 hover:to-purple-100 dark:from-blue-900/20 dark:to-purple-900/20 dark:hover:from-blue-900/30 dark:hover:to-purple-900/30 text-blue-700 dark:text-blue-300 rounded-full text-sm font-medium transition-all duration-200 whitespace-nowrap border border-blue-200 dark:border-blue-700 hover:scale-105 transform"
        >
          {suggestion.icon}
          {suggestion.text}
        </button>
      ))}
    </div>
  );
};