import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface BackToTopButtonProps {
  scrollContainerRef: React.RefObject<HTMLDivElement>;
}

export const BackToTopButton: React.FC<BackToTopButtonProps> = ({ scrollContainerRef }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [isAtBottom, setIsAtBottom] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    const scrollContainer = scrollContainerRef.current;
    if (!scrollContainer) return;

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = scrollContainer;
      const scrollPercentage = (scrollTop / (scrollHeight - clientHeight)) * 100;
      
      // Show button when scrolled more than 20% from top
      setIsVisible(scrollPercentage > 20);
      
      // Check if near bottom (within 100px)
      setIsAtBottom(scrollHeight - scrollTop - clientHeight < 100);
    };

    scrollContainer.addEventListener('scroll', handleScroll);
    return () => scrollContainer.removeEventListener('scroll', handleScroll);
  }, [scrollContainerRef]);

  const scrollToTop = () => {
    scrollContainerRef.current?.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  if (!isVisible) return null;

  return (
    <button
      onClick={scrollToTop}
      className={`
        fixed right-6 z-40 p-3 rounded-full shadow-lg transition-all duration-300 transform hover:scale-110 active:scale-95
        ${isAtBottom 
          ? 'bottom-24 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700' 
          : 'bottom-6 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700'
        }
        text-white animate-in slide-in-from-bottom-2 duration-300
      `}
      title={t('back_to_top')}
    >
      <ArrowUp className="w-5 h-5" />
    </button>
  );
};