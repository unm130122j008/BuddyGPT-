import React from 'react';
import { EnhancedTypingIndicator } from './EnhancedTypingIndicator';

export const TypingIndicator: React.FC = () => {
  return <EnhancedTypingIndicator />;
};