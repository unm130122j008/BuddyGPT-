import React, { useState, useEffect } from 'react';
import { Sparkles, RefreshCw } from 'lucide-react';

export const MotivationalQuotes: React.FC = () => {
  const [currentQuote, setCurrentQuote] = useState(0);

  const quotes = [
    "Where love leads, experience follows 💕",
    "Every moment lived with love becomes a story worth remembering ✨",
    "Love teaches what time can only prove 🌟",
    "Experience shapes us, love defines us 💖",
    "The best lessons come from the heart ❤️",
    "Love deeply, live fully, learn constantly 🌈",
    "It's not just about years lived, but love felt 💫",
    "What we love becomes our greatest experience 🎯",
    "In every experience, love leaves its mark 💝",
    "Love isn't just felt — it's lived 🌸",
    "Every step forward is progress 🚀",
    "Believe in the power of starting small 🌱",
    "Create. Grow. Inspire. ✨",
    "Dream big. Start now 💫",
    "Positivity fuels possibility 🌟",
    "One day or day one — you decide 🎯",
    "Progress, not perfection 📈",
    "Shine through every challenge ✨",
    "Keep going. You're closer than you think 🏆",
    "Do what you love. Love what you do 💖"
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentQuote((prev) => (prev + 1) % quotes.length);
    }, 8000); // Changed to 8 seconds for better readability

    return () => clearInterval(interval);
  }, []);

  const nextQuote = () => {
    setCurrentQuote((prev) => (prev + 1) % quotes.length);
  };

  return (
    <div className="flex items-center justify-between bg-gradient-to-r from-blue-50/50 via-purple-50/50 to-pink-50/50 dark:from-blue-900/10 dark:via-purple-900/10 dark:to-pink-900/10 rounded-lg px-4 py-2 animate-in fade-in duration-1000">
      <div className="flex items-center gap-3 flex-1 min-w-0">
        <div className="p-1.5 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex-shrink-0">
          <Sparkles className="w-3 h-3 text-white" />
        </div>
        <p className="text-sm font-medium bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent animate-in slide-in-from-left-2 duration-500 truncate">
          {quotes[currentQuote]}
        </p>
      </div>
      <button
        onClick={nextQuote}
        className="p-1 hover:bg-white/50 dark:hover:bg-gray-800/50 rounded-lg transition-colors flex-shrink-0 ml-2"
        title="Next quote"
      >
        <RefreshCw className="w-3 h-3 text-purple-600" />
      </button>
    </div>
  );
};