import React, { useState, useEffect } from 'react';
import { Clock, User, MessageCircle, Lightbulb } from 'lucide-react';

interface MemoryItem {
  id: string;
  type: 'preference' | 'fact' | 'goal' | 'interest';
  content: string;
  timestamp: Date;
  relevance: number;
}

interface ContextualMemoryProps {
  currentMessage: string;
  onMemoryRecall: (memories: MemoryItem[]) => void;
}

export const ContextualMemory: React.FC<ContextualMemoryProps> = ({ currentMessage, onMemoryRecall }) => {
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [relevantMemories, setRelevantMemories] = useState<MemoryItem[]>([]);

  useEffect(() => {
    // Load memories from localStorage
    const savedMemories = localStorage.getItem('buddygpt-memories');
    if (savedMemories) {
      setMemories(JSON.parse(savedMemories));
    }
  }, []);

  useEffect(() => {
    if (currentMessage) {
      extractAndStoreMemories(currentMessage);
      const relevant = findRelevantMemories(currentMessage);
      setRelevantMemories(relevant);
      onMemoryRecall(relevant);
    }
  }, [currentMessage, memories]);

  const extractAndStoreMemories = (message: string) => {
    const lower = message.toLowerCase();
    const newMemories: MemoryItem[] = [];

    // Extract preferences
    const preferencePatterns = [
      /i (like|love|prefer|enjoy) (.+)/gi,
      /my favorite (.+) is (.+)/gi,
      /i (hate|dislike|don't like) (.+)/gi
    ];

    preferencePatterns.forEach(pattern => {
      const matches = message.match(pattern);
      if (matches) {
        matches.forEach(match => {
          newMemories.push({
            id: Date.now().toString() + Math.random(),
            type: 'preference',
            content: match,
            timestamp: new Date(),
            relevance: 1
          });
        });
      }
    });

    // Extract facts about user
    const factPatterns = [
      /i am (.+)/gi,
      /i work (.+)/gi,
      /i live (.+)/gi,
      /my (.+) is (.+)/gi
    ];

    factPatterns.forEach(pattern => {
      const matches = message.match(pattern);
      if (matches) {
        matches.forEach(match => {
          newMemories.push({
            id: Date.now().toString() + Math.random(),
            type: 'fact',
            content: match,
            timestamp: new Date(),
            relevance: 1
          });
        });
      }
    });

    // Extract goals
    const goalPatterns = [
      /i want to (.+)/gi,
      /i'm trying to (.+)/gi,
      /my goal is (.+)/gi,
      /i hope to (.+)/gi
    ];

    goalPatterns.forEach(pattern => {
      const matches = message.match(pattern);
      if (matches) {
        matches.forEach(match => {
          newMemories.push({
            id: Date.now().toString() + Math.random(),
            type: 'goal',
            content: match,
            timestamp: new Date(),
            relevance: 1
          });
        });
      }
    });

    // Extract interests
    const interestKeywords = ['interested in', 'passionate about', 'hobby', 'fascinated by'];
    interestKeywords.forEach(keyword => {
      if (lower.includes(keyword)) {
        newMemories.push({
          id: Date.now().toString() + Math.random(),
          type: 'interest',
          content: message,
          timestamp: new Date(),
          relevance: 1
        });
      }
    });

    if (newMemories.length > 0) {
      const updatedMemories = [...memories, ...newMemories];
      setMemories(updatedMemories);
      localStorage.setItem('buddygpt-memories', JSON.stringify(updatedMemories));
    }
  };

  const findRelevantMemories = (message: string): MemoryItem[] => {
    const lower = message.toLowerCase();
    const words = lower.split(' ').filter(word => word.length > 3);
    
    return memories
      .map(memory => {
        const memoryWords = memory.content.toLowerCase().split(' ');
        const commonWords = words.filter(word => memoryWords.some(mWord => mWord.includes(word)));
        const relevanceScore = commonWords.length / words.length;
        
        return { ...memory, relevance: relevanceScore };
      })
      .filter(memory => memory.relevance > 0.2)
      .sort((a, b) => b.relevance - a.relevance)
      .slice(0, 3);
  };

  const getMemoryIcon = (type: string) => {
    switch (type) {
      case 'preference': return <User className="w-3 h-3" />;
      case 'fact': return <MessageCircle className="w-3 h-3" />;
      case 'goal': return <Lightbulb className="w-3 h-3" />;
      case 'interest': return <Clock className="w-3 h-3" />;
      default: return <MessageCircle className="w-3 h-3" />;
    }
  };

  const getMemoryColor = (type: string) => {
    switch (type) {
      case 'preference': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'fact': return 'bg-green-100 text-green-700 border-green-200';
      case 'goal': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'interest': return 'bg-orange-100 text-orange-700 border-orange-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  if (relevantMemories.length === 0) return null;

  return (
    <div className="mb-3 animate-in slide-in-from-top-2 duration-300">
      <div className="flex items-center gap-2 mb-2">
        <Clock className="w-4 h-4 text-purple-600" />
        <span className="text-sm font-medium text-purple-600">Remembering about you:</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {relevantMemories.map(memory => (
          <div
            key={memory.id}
            className={`inline-flex items-center gap-1 px-2 py-1 rounded-full border text-xs ${getMemoryColor(memory.type)}`}
          >
            {getMemoryIcon(memory.type)}
            <span className="truncate max-w-32">{memory.content.slice(0, 30)}...</span>
          </div>
        ))}
      </div>
    </div>
  );
};