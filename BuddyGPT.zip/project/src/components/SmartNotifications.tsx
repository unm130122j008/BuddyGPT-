import React, { useState, useEffect } from 'react';
import { Bell, X, CheckCircle, AlertCircle, Info, Zap } from 'lucide-react';

interface Notification {
  id: string;
  type: 'tip' | 'reminder' | 'achievement' | 'suggestion';
  title: string;
  message: string;
  timestamp: Date;
  action?: () => void;
  actionText?: string;
}

interface SmartNotificationsProps {
  userActivity: {
    messageCount: number;
    lastActiveTime: Date;
    currentStreak: number;
  };
}

export const SmartNotifications: React.FC<SmartNotificationsProps> = ({ userActivity }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    generateSmartNotifications();
  }, [userActivity]);

  const generateSmartNotifications = () => {
    const newNotifications: Notification[] = [];
    const now = new Date();

    // Achievement notifications
    if (userActivity.messageCount === 10) {
      newNotifications.push({
        id: 'achievement-10',
        type: 'achievement',
        title: '🎉 Chatty Explorer!',
        message: 'You\'ve sent 10 messages! You\'re getting the hang of this.',
        timestamp: now
      });
    }

    if (userActivity.currentStreak >= 3) {
      newNotifications.push({
        id: 'streak-3',
        type: 'achievement',
        title: '🔥 On Fire!',
        message: `${userActivity.currentStreak} days streak! Keep the conversation going!`,
        timestamp: now
      });
    }

    // Smart tips based on usage
    if (userActivity.messageCount > 5 && userActivity.messageCount < 15) {
      newNotifications.push({
        id: 'tip-voice',
        type: 'tip',
        title: '🎤 Pro Tip',
        message: 'Try voice input! Click the mic button to speak instead of typing.',
        timestamp: now,
        action: () => console.log('Voice tip clicked'),
        actionText: 'Try it'
      });
    }

    // Time-based suggestions
    const hour = now.getHours();
    if (hour >= 9 && hour <= 11) {
      newNotifications.push({
        id: 'morning-productivity',
        type: 'suggestion',
        title: '☀️ Morning Boost',
        message: 'Perfect time for planning! Want me to help organize your day?',
        timestamp: now,
        action: () => console.log('Morning planning'),
        actionText: 'Let\'s plan'
      });
    }

    if (hour >= 14 && hour <= 16) {
      newNotifications.push({
        id: 'afternoon-break',
        type: 'suggestion',
        title: '☕ Afternoon Break',
        message: 'How about a quick creative break? I can help you brainstorm!',
        timestamp: now,
        action: () => console.log('Creative break'),
        actionText: 'Get creative'
      });
    }

    // Filter out existing notifications
    const existingIds = notifications.map(n => n.id);
    const filteredNew = newNotifications.filter(n => !existingIds.includes(n.id));
    
    if (filteredNew.length > 0) {
      setNotifications(prev => [...prev, ...filteredNew]);
    }
  };

  const dismissNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'achievement': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'tip': return <Info className="w-4 h-4 text-blue-500" />;
      case 'reminder': return <AlertCircle className="w-4 h-4 text-orange-500" />;
      case 'suggestion': return <Zap className="w-4 h-4 text-purple-500" />;
      default: return <Bell className="w-4 h-4 text-gray-500" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'achievement': return 'bg-green-50 border-green-200';
      case 'tip': return 'bg-blue-50 border-blue-200';
      case 'reminder': return 'bg-orange-50 border-orange-200';
      case 'suggestion': return 'bg-purple-50 border-purple-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50">
      <button
        onClick={() => setShowNotifications(!showNotifications)}
        className="relative p-2 bg-white dark:bg-gray-800 rounded-full shadow-lg border border-gray-200 dark:border-gray-700 hover:scale-105 transition-transform"
      >
        <Bell className="w-5 h-5 text-gray-600 dark:text-gray-300" />
        {notifications.length > 0 && (
          <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
            <span className="text-xs text-white font-bold">{notifications.length}</span>
          </div>
        )}
      </button>

      {showNotifications && (
        <div className="absolute top-12 right-0 w-80 max-h-96 overflow-y-auto bg-white dark:bg-gray-800 rounded-lg shadow-xl border border-gray-200 dark:border-gray-700 animate-in slide-in-from-top-2 duration-200">
          <div className="p-3 border-b border-gray-200 dark:border-gray-700">
            <h3 className="font-semibold text-gray-900 dark:text-gray-100">Notifications</h3>
          </div>
          
          <div className="max-h-80 overflow-y-auto">
            {notifications.map(notification => (
              <div
                key={notification.id}
                className={`p-3 border-b border-gray-100 dark:border-gray-700 last:border-b-0 ${getNotificationColor(notification.type)} animate-in slide-in-from-right-2 duration-300`}
              >
                <div className="flex items-start gap-3">
                  {getNotificationIcon(notification.type)}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm text-gray-900 dark:text-gray-100">
                      {notification.title}
                    </h4>
                    <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                      {notification.message}
                    </p>
                    {notification.action && (
                      <button
                        onClick={notification.action}
                        className="mt-2 px-3 py-1 bg-blue-600 text-white text-xs rounded-full hover:bg-blue-700 transition-colors"
                      >
                        {notification.actionText}
                      </button>
                    )}
                  </div>
                  <button
                    onClick={() => dismissNotification(notification.id)}
                    className="p-1 hover:bg-gray-200 dark:hover:bg-gray-600 rounded-full transition-colors"
                  >
                    <X className="w-3 h-3 text-gray-500" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};