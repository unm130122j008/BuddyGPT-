import React from 'react';
import { Shield, Eye, EyeOff, AlertTriangle, Info } from 'lucide-react';
import { useIncognito } from '../contexts/IncognitoContext';
import { useLanguage } from '../contexts/LanguageContext';

interface AdvancedSettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AdvancedSettings: React.FC<AdvancedSettingsProps> = ({ isOpen, onClose }) => {
  const { isIncognitoMode, toggleIncognitoMode } = useIncognito();
  const { t } = useLanguage();

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/50 z-50" onClick={onClose} />
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 bg-white dark:bg-gray-800 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 z-50 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-purple-600" />
            <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
              {t('advanced_settings')}
            </h2>
          </div>
        </div>

        {/* Settings Content */}
        <div className="p-6 space-y-6">
          {/* Incognito Mode Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${isIncognitoMode ? 'bg-purple-100 dark:bg-purple-900/20' : 'bg-gray-100 dark:bg-gray-700'}`}>
                {isIncognitoMode ? (
                  <EyeOff className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                ) : (
                  <Eye className="w-5 h-5 text-gray-600 dark:text-gray-400" />
                )}
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900 dark:text-gray-100">
                  {t('incognito_mode')}
                </h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {t('incognito_description')}
                </p>
              </div>
              <button
                onClick={toggleIncognitoMode}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800 ${
                  isIncognitoMode ? 'bg-purple-600' : 'bg-gray-200 dark:bg-gray-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    isIncognitoMode ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Incognito Mode Info */}
            {isIncognitoMode && (
              <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-700 rounded-lg p-4 animate-in slide-in-from-top-2 duration-300">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-purple-600 dark:text-purple-400 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <h4 className="font-medium text-purple-900 dark:text-purple-100">
                      {t('incognito_active')}
                    </h4>
                    <div className="text-sm text-purple-700 dark:text-purple-300 space-y-1">
                      <p className="font-medium">{t('does_not_save')}:</p>
                      <ul className="list-disc list-inside space-y-1 ml-2">
                        <li>{t('chat_history')}</li>
                        <li>{t('search_history')}</li>
                        <li>{t('user_preferences')}</li>
                        <li>{t('conversation_insights')}</li>
                        <li>{t('contextual_memory')}</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Regular Mode Info */}
            {!isIncognitoMode && (
              <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Info className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2">
                    <h4 className="font-medium text-blue-900 dark:text-blue-100">
                      {t('normal_mode_active')}
                    </h4>
                    <div className="text-sm text-blue-700 dark:text-blue-300 space-y-1">
                      <p>{t('normal_mode_description')}</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Privacy Notice */}
          <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
            <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-2">
              {t('privacy_notice')}
            </h4>
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
              {t('privacy_notice_text')}
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 dark:border-gray-700 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 dark:focus:ring-offset-gray-800"
          >
            {t('close')}
          </button>
        </div>
      </div>
    </>
  );
};