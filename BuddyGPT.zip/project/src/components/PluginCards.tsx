import React from 'react';
import { Cloud, Sun, CloudRain, Wind, Newspaper, Calculator, ExternalLink, Calendar, MapPin, Thermometer } from 'lucide-react';
import { WeatherData, NewsArticle, CalculatorResult } from '../types';
import { ImageGenerationCard } from './ImageGenerationCard';

interface WeatherCardProps {
  data: WeatherData;
}

export const WeatherCard: React.FC<WeatherCardProps> = ({ data }) => {
  const getWeatherIcon = (condition: string) => {
    const lower = condition.toLowerCase();
    if (lower.includes('rain') || lower.includes('drizzle')) return <CloudRain className="w-8 h-8 text-blue-500" />;
    if (lower.includes('cloud')) return <Cloud className="w-8 h-8 text-gray-500" />;
    if (lower.includes('sun') || lower.includes('clear')) return <Sun className="w-8 h-8 text-yellow-500" />;
    if (lower.includes('snow')) return <Cloud className="w-8 h-8 text-blue-300" />;
    return <Cloud className="w-8 h-8 text-gray-500" />;
  };

  const getTemperatureColor = (temp: number) => {
    if (temp >= 30) return 'text-red-600 dark:text-red-400';
    if (temp >= 20) return 'text-orange-600 dark:text-orange-400';
    if (temp >= 10) return 'text-blue-600 dark:text-blue-400';
    return 'text-blue-800 dark:text-blue-300';
  };

  return (
    <div className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border border-blue-200 dark:border-blue-700 rounded-xl p-6 my-4 animate-in slide-in-from-bottom-3 duration-500">
      <div className="flex items-center gap-4 mb-6">
        <div className="p-3 bg-white dark:bg-gray-800 rounded-full shadow-lg">
          {getWeatherIcon(data.condition)}
        </div>
        <div>
          <div className="flex items-center gap-2 mb-1">
            <MapPin className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">{data.location}</h3>
          </div>
          <div className="flex items-center gap-2">
            <Thermometer className="w-5 h-5 text-gray-500" />
            <p className={`text-3xl font-bold ${getTemperatureColor(data.temperature)}`}>
              {data.temperature}°C
            </p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Cloud className="w-4 h-4 text-gray-600 dark:text-gray-400" />
            <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">Condition</p>
          </div>
          <p className="font-semibold text-gray-900 dark:text-gray-100 capitalize">{data.condition}</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-4 h-4 bg-blue-500 rounded-full opacity-60"></div>
            <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">Humidity</p>
          </div>
          <p className="font-semibold text-gray-900 dark:text-gray-100">{data.humidity}%</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Wind className="w-4 h-4 text-gray-600 dark:text-gray-400" />
            <p className="text-sm text-gray-600 dark:text-gray-400 font-medium">Wind Speed</p>
          </div>
          <p className="font-semibold text-gray-900 dark:text-gray-100">{data.windSpeed} km/h</p>
        </div>
      </div>

      <div className="mt-4 p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
        <p className="text-xs text-blue-700 dark:text-blue-300 text-center">
          🌍 Real-time weather data • Updated every hour
        </p>
      </div>
    </div>
  );
};

interface NewsCardProps {
  articles: NewsArticle[];
}

export const NewsCard: React.FC<NewsCardProps> = ({ articles }) => {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffHours < 1) return 'Just now';
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined
    });
  };

  return (
    <div className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 border border-purple-200 dark:border-purple-700 rounded-xl p-6 my-4 animate-in slide-in-from-bottom-3 duration-500">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-white dark:bg-gray-800 rounded-full shadow-lg">
          <Newspaper className="w-6 h-6 text-purple-600 dark:text-purple-400" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">Latest News</h3>
          <p className="text-sm text-purple-600 dark:text-purple-400">
            📰 {articles.length} articles • Real-time updates
          </p>
        </div>
      </div>
      
      <div className="space-y-4">
        {articles.map((article, index) => (
          <div key={index} className="bg-white dark:bg-gray-800 rounded-lg p-4 hover:shadow-md transition-all duration-200 border border-gray-100 dark:border-gray-700">
            <div className="flex gap-4">
              {article.urlToImage && (
                <div className="flex-shrink-0">
                  <img 
                    src={article.urlToImage} 
                    alt={article.title}
                    className="w-20 h-20 object-cover rounded-lg"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = 'https://images.pexels.com/photos/518543/pexels-photo-518543.jpeg?auto=compress&cs=tinysrgb&w=400';
                    }}
                  />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <h4 className="font-semibold text-gray-900 dark:text-gray-100 line-clamp-2 mb-2 hover:text-purple-600 dark:hover:text-purple-400 transition-colors">
                  {article.title}
                </h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mb-3">
                  {article.description}
                </p>
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-3 text-gray-500 dark:text-gray-400">
                    <span className="font-medium text-purple-600 dark:text-purple-400">
                      {article.source}
                    </span>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      <span>{formatDate(article.publishedAt)}</span>
                    </div>
                  </div>
                  <a 
                    href={article.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-purple-600 dark:text-purple-400 hover:text-purple-800 dark:hover:text-purple-300 transition-colors font-medium"
                  >
                    <span>Read more</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 p-3 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
        <p className="text-xs text-purple-700 dark:text-purple-300 text-center">
          📡 Live news feed • Powered by NewsAPI
        </p>
      </div>
    </div>
  );
};

interface CalculatorCardProps {
  result: CalculatorResult;
}

export const CalculatorCard: React.FC<CalculatorCardProps> = ({ result }) => {
  const isError = result.result.includes('Error');
  
  return (
    <div className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border border-green-200 dark:border-green-700 rounded-xl p-6 my-4 animate-in slide-in-from-bottom-3 duration-500">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-white dark:bg-gray-800 rounded-full shadow-lg">
          <Calculator className="w-6 h-6 text-green-600 dark:text-green-400" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-900 dark:text-gray-100">Calculator</h3>
          <p className="text-sm text-green-600 dark:text-green-400">
            🧮 Mathematical computation
          </p>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Expression:</span>
          </div>
          <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-3">
            <p className="text-lg font-mono text-gray-900 dark:text-gray-100 break-all">
              {result.expression}
            </p>
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Result:</span>
          </div>
          <div className={`rounded-lg p-3 ${isError ? 'bg-red-50 dark:bg-red-900/20' : 'bg-green-50 dark:bg-green-900/20'}`}>
            <p className={`text-2xl font-bold font-mono break-all ${
              isError 
                ? 'text-red-600 dark:text-red-400' 
                : 'text-green-600 dark:text-green-400'
            }`}>
              {result.result}
            </p>
          </div>
        </div>
        
        {result.steps && result.steps.length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-100 dark:border-gray-700">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Steps:</span>
            </div>
            <div className="space-y-2">
              {result.steps.map((step, index) => (
                <div key={index} className="flex items-start gap-3 text-sm">
                  <span className="flex-shrink-0 w-6 h-6 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center text-xs font-bold">
                    {index + 1}
                  </span>
                  <p className="text-gray-700 dark:text-gray-300 font-mono">{step}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="mt-4 p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
        <p className="text-xs text-green-700 dark:text-green-300 text-center">
          ⚡ Powered by MathJS • Supports advanced mathematical operations
        </p>
      </div>
    </div>
  );
};

// Export the ImageGenerationCard for use in other components
export { ImageGenerationCard };