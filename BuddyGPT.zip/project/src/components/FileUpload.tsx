import React, { useRef, useState } from 'react';
import { Upload, X, FileText, Image, AlertCircle, File, FileImage } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  onRemoveFile: () => void;
  selectedFile: File | null;
  isUploading: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({
  onFileSelect,
  onRemoveFile,
  selectedFile,
  isUploading
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    const validFile = files.find(file => isValidFile(file));
    
    if (validFile) {
      onFileSelect(validFile);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && isValidFile(file)) {
      onFileSelect(file);
    }
  };

  const isValidFile = (file: File): boolean => {
    const validTypes = [
      // Images
      'image/jpeg',
      'image/jpg',
      'image/png',
      'image/gif',
      'image/webp',
      'image/bmp',
      'image/svg+xml',
      // Documents
      'application/pdf',
      'text/plain',
      'text/csv',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-powerpoint',
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'application/json',
      'text/markdown'
    ];
    const maxSize = 25 * 1024 * 1024; // 25MB
    
    return validTypes.includes(file.type) && file.size <= maxSize;
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) {
      return <FileImage className="w-4 h-4" />;
    }
    if (file.type === 'application/pdf') {
      return <FileText className="w-4 h-4 text-red-500" />;
    }
    if (file.type.includes('word') || file.type.includes('document')) {
      return <FileText className="w-4 h-4 text-blue-500" />;
    }
    if (file.type.includes('excel') || file.type.includes('sheet')) {
      return <FileText className="w-4 h-4 text-green-500" />;
    }
    if (file.type.includes('powerpoint') || file.type.includes('presentation')) {
      return <FileText className="w-4 h-4 text-orange-500" />;
    }
    return <File className="w-4 h-4" />;
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getFileTypeLabel = (file: File): string => {
    if (file.type.startsWith('image/')) return 'Image';
    if (file.type === 'application/pdf') return 'PDF';
    if (file.type.includes('word')) return 'Word';
    if (file.type.includes('excel')) return 'Excel';
    if (file.type.includes('powerpoint')) return 'PowerPoint';
    if (file.type === 'text/plain') return 'Text';
    if (file.type === 'text/csv') return 'CSV';
    return 'File';
  };

  if (selectedFile) {
    return (
      <div className="animate-in slide-in-from-bottom-2 duration-300">
        <div className="flex items-center gap-3 p-2 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border border-blue-200 dark:border-blue-700 rounded-lg">
          <div className="flex-shrink-0">
            <div className="p-1 bg-white dark:bg-gray-800 rounded-md shadow-sm">
              {getFileIcon(selectedFile)}
            </div>
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <p className="text-sm font-medium text-blue-900 dark:text-blue-100 truncate">
                {selectedFile.name}
              </p>
              <span className="px-1.5 py-0.5 bg-blue-100 dark:bg-blue-800 text-blue-700 dark:text-blue-300 text-xs rounded font-medium">
                {getFileTypeLabel(selectedFile)}
              </span>
            </div>
            <p className="text-xs text-blue-600 dark:text-blue-400">
              {formatFileSize(selectedFile.size)} • Ready for analysis
            </p>
          </div>
          
          {isUploading ? (
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
              <span className="text-xs text-blue-600 dark:text-blue-400 font-medium">Processing...</span>
            </div>
          ) : (
            <button
              onClick={onRemoveFile}
              className="p-1 hover:bg-blue-100 dark:hover:bg-blue-800 rounded-md text-blue-600 dark:text-blue-400 transition-colors"
              title="Remove file"
            >
              <X className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="animate-in slide-in-from-bottom-2 duration-300">
      <div
        className={`
          relative border-2 border-dashed rounded-lg p-3 transition-all duration-300 cursor-pointer group
          ${isDragOver 
            ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 scale-105' 
            : 'border-gray-300 dark:border-gray-600 hover:border-blue-400 hover:bg-gray-50 dark:hover:bg-gray-800'
          }
        `}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,.pdf,.txt,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.csv,.json,.md"
          onChange={handleFileSelect}
          className="hidden"
        />
        
        <div className="flex flex-col items-center gap-2 text-center">
          <div className={`p-2 rounded-full transition-all duration-300 ${
            isDragOver 
              ? 'bg-blue-100 dark:bg-blue-800 scale-110' 
              : 'bg-gray-100 dark:bg-gray-700 group-hover:bg-blue-50 dark:group-hover:bg-blue-900/20'
          }`}>
            <Upload className={`w-4 h-4 transition-colors duration-300 ${
              isDragOver 
                ? 'text-blue-600 dark:text-blue-400' 
                : 'text-gray-500 dark:text-gray-400 group-hover:text-blue-500'
            }`} />
          </div>
          
          <div className="space-y-1">
            <h3 className={`text-sm font-semibold transition-colors ${
              isDragOver 
                ? 'text-blue-700 dark:text-blue-300' 
                : 'text-gray-900 dark:text-gray-100'
            }`}>
              {isDragOver ? 'Drop your file here!' : 'Upload & Analyze'}
            </h3>
            
            <p className="text-xs text-gray-600 dark:text-gray-400">
              Drag & drop or click to upload
            </p>
            
            <div className="flex items-center justify-center gap-3 mt-2 text-xs text-gray-500 dark:text-gray-400">
              <div className="flex items-center gap-1">
                <FileImage className="w-2 h-2" />
                <span>Images</span>
              </div>
              <div className="flex items-center gap-1">
                <FileText className="w-2 h-2" />
                <span>Docs</span>
              </div>
              <div className="flex items-center gap-1">
                <AlertCircle className="w-2 h-2" />
                <span>25MB</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};