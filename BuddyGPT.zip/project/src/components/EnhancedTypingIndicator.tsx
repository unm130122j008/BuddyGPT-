import React from 'react';
import { Sparkles, Brain, Zap, Bot } from 'lucide-react';

export const EnhancedTypingIndicator: React.FC = () => {
  const [currentPhase, setCurrentPhase] = React.useState(0);
  
  const phases = [
    { icon: <Brain className="w-4 h-4" />, text: "Thinking...", color: "text-blue-500" },
    { icon: <Zap className="w-4 h-4" />, text: "Processing...", color: "text-purple-500" },
    { icon: <Sparkles className="w-4 h-4" />, text: "Almost ready...", color: "text-green-500" }
  ];

  React.useEffect(() => {
    const interval = setInterval(() => {
      setCurrentPhase(prev => (prev + 1) % phases.length);
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  const currentPhaseData = phases[currentPhase];

  return (
    <div className="flex gap-4 p-4 bg-gradient-to-r from-gray-50 to-blue-50/30 dark:from-gray-800/50 dark:to-blue-900/10 animate-in slide-in-from-bottom-2 duration-300">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 via-blue-600 to-cyan-500 text-white flex items-center justify-center shadow-lg animate-pulse">
        <Bot className="w-4 h-4" />
      </div>
      
      <div className="flex-1 space-y-2">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-sm bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            BuddyGPT
          </span>
          <div className="flex items-center gap-1">
            <div className="w-1 h-1 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-xs text-green-600 dark:text-green-400 font-medium">Online</span>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex space-x-1">
            <div className="w-2 h-2 bg-gradient-to-r from-blue-400 to-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
            <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
            <div className="w-2 h-2 bg-gradient-to-r from-pink-400 to-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
          </div>
          
          <div className={`flex items-center gap-2 transition-all duration-500 ${currentPhaseData.color}`}>
            <div className="animate-spin">
              {currentPhaseData.icon}
            </div>
            <span className="text-sm font-medium animate-pulse">
              {currentPhaseData.text}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};