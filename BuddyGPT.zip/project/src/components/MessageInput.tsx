import React, { useState, useRef, useEffect } from 'react';
import { Send, Loader2, Wrench, Image as ImageIcon, Paperclip } from 'lucide-react';
import { useChat } from '../contexts/ChatContext';
import { useLanguage } from '../contexts/LanguageContext';
import { FileUpload } from './FileUpload';
import { VoiceInput } from './VoiceInput';
import { useVoiceOutput } from '../hooks/useVoiceOutput';

interface MessageInputProps {
  onOpenTools?: () => void;
}

export const MessageInput: React.FC<MessageInputProps> = ({ onOpenTools }) => {
  const [input, setInput] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [showFileUpload, setShowFileUpload] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [pastedImage, setPastedImage] = useState<string | null>(null);
  const { sendMessage, isTyping, currentChat } = useChat();
  const { isTTSEnabled, toggleTTS } = useVoiceOutput();
  const { t } = useLanguage();
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!input.trim() && !selectedFile && !pastedImage) || isTyping || !currentChat) return;

    const message = input.trim();
    let file = selectedFile;
    
    // Convert pasted image to File object if exists
    if (pastedImage && !file) {
      try {
        const response = await fetch(pastedImage);
        const blob = await response.blob();
        file = new File([blob], 'pasted-image.png', { type: 'image/png' });
      } catch (error) {
        console.error('Error converting pasted image:', error);
      }
    }
    
    setInput('');
    setSelectedFile(null);
    setPastedImage(null);
    setShowFileUpload(false);
    setIsUploading(false);
    
    await sendMessage(message || "Please analyze this file", file);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handlePaste = async (e: React.ClipboardEvent) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      
      if (item.type.indexOf('image') !== -1) {
        e.preventDefault();
        const file = item.getAsFile();
        if (file) {
          // Create preview URL for pasted image
          const imageUrl = URL.createObjectURL(file);
          setPastedImage(imageUrl);
          setSelectedFile(file);
          
          // Auto-focus and add helpful text
          if (!input.trim()) {
            setInput("What do you see in this image?");
          }
          
          // Show upload indicator briefly
          setIsUploading(true);
          setTimeout(() => setIsUploading(false), 500);
        }
        break;
      }
    }
  };

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    setPastedImage(null); // Clear any pasted image
    setIsUploading(true);
    
    // Auto-suggest analysis prompt based on file type
    if (!input.trim()) {
      if (file.type.startsWith('image/')) {
        setInput("Analyze this image and tell me what you see");
      } else if (file.type === 'application/pdf') {
        setInput("Summarize the key points from this PDF document");
      } else if (file.type.includes('word') || file.type.includes('document')) {
        setInput("Analyze this document and provide insights");
      } else if (file.type.includes('excel') || file.type.includes('sheet')) {
        setInput("Analyze this spreadsheet data");
      } else {
        setInput("Analyze this file and provide insights");
      }
    }
    
    setTimeout(() => setIsUploading(false), 1000);
  };

  const handleRemoveFile = () => {
    setSelectedFile(null);
    setPastedImage(null);
    setIsUploading(false);
    
    // Clean up object URL to prevent memory leaks
    if (pastedImage) {
      URL.revokeObjectURL(pastedImage);
    }
  };

  const handleVoiceInput = (text: string) => {
    setInput(prev => prev + (prev ? ' ' : '') + text);
    textareaRef.current?.focus();
  };

  // Auto-resize textarea
  useEffect(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = Math.min(textarea.scrollHeight, 120) + 'px';
    }
  }, [input]);

  // Cleanup object URLs on unmount
  useEffect(() => {
    return () => {
      if (pastedImage) {
        URL.revokeObjectURL(pastedImage);
      }
    };
  }, [pastedImage]);

  if (!currentChat) {
    return null;
  }

  return (
    <div className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm p-4">
      <div className="max-w-4xl mx-auto space-y-3">
        {/* File Upload Area */}
        {showFileUpload && (
          <div className="animate-in slide-in-from-bottom-2 duration-200">
            <FileUpload
              onFileSelect={handleFileSelect}
              onRemoveFile={handleRemoveFile}
              selectedFile={selectedFile}
              isUploading={isUploading}
            />
          </div>
        )}

        {/* Pasted Image Preview */}
        {pastedImage && (
          <div className="animate-in slide-in-from-bottom-2 duration-200">
            <div className="flex items-center gap-3 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg">
              <ImageIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <div className="flex-1">
                <img 
                  src={pastedImage} 
                  alt="Pasted image" 
                  className="max-h-20 rounded-lg object-cover"
                />
                <p className="text-sm font-medium text-blue-900 dark:text-blue-100 mt-1">
                  📋 Image pasted - ready to analyze!
                </p>
              </div>
              <button
                onClick={handleRemoveFile}
                className="p-1 rounded-full hover:bg-blue-100 dark:hover:bg-blue-800 text-blue-600 dark:text-blue-400 transition-colors"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* Selected File Display */}
        {selectedFile && !showFileUpload && !pastedImage && (
          <div className="animate-in slide-in-from-bottom-2 duration-200">
            <FileUpload
              onFileSelect={handleFileSelect}
              onRemoveFile={handleRemoveFile}
              selectedFile={selectedFile}
              isUploading={isUploading}
            />
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="flex items-end gap-3">
            {/* File Upload Button - Left side */}
            <button
              type="button"
              onClick={() => setShowFileUpload(!showFileUpload)}
              className={`flex-shrink-0 p-3 rounded-xl transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900 transform hover:scale-105 shadow-lg ${
                showFileUpload || selectedFile
                  ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white'
                  : 'bg-gradient-to-r from-gray-600 to-gray-700 hover:from-blue-600 hover:to-purple-600 text-white'
              }`}
              title="Upload files for analysis"
            >
              <Paperclip className="w-5 h-5" />
            </button>

            {/* Tools Button */}
            <button
              type="button"
              onClick={onOpenTools}
              className="flex-shrink-0 p-3 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900 transform hover:scale-105 shadow-lg"
              title={t('open_tools')}
            >
              <Wrench className="w-5 h-5" />
            </button>

            {/* Centered Input Container */}
            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                onPaste={handlePaste}
                placeholder={
                  selectedFile || pastedImage 
                    ? `Ask about your ${selectedFile?.type.startsWith('image/') ? 'image' : 'file'}...`
                    : 'Message BuddyGPT, paste/upload files, or generate images... 🌍✨'
                }
                disabled={isTyping}
                className="w-full resize-none rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-4 py-3 text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed shadow-sm"
                style={{ minHeight: '48px', maxHeight: '120px' }}
              />
              
              {isTyping && (
                <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                    <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                    <div className="w-2 h-2 bg-gradient-to-r from-pink-500 to-blue-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                  </div>
                </div>
              )}
            </div>

            {/* Send Button - Right side */}
            <button
              type="submit"
              disabled={(!input.trim() && !selectedFile && !pastedImage) || isTyping}
              className="flex-shrink-0 p-3 rounded-xl bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 disabled:from-gray-300 disabled:via-gray-300 disabled:to-gray-300 dark:disabled:from-gray-600 dark:disabled:via-gray-600 dark:disabled:to-gray-600 text-white transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900 disabled:cursor-not-allowed transform hover:scale-105 active:scale-95 shadow-lg"
            >
              {isTyping ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Send className="w-5 h-5" />
              )}
            </button>
          </div>
        </form>

        {/* Quick Actions */}
        {!selectedFile && !showFileUpload && (
          <div className="flex items-center justify-center gap-2 text-xs text-gray-500 dark:text-gray-400">
            <span>💡 Try:</span>
            <button 
              onClick={() => setInput("Generate an image of a beautiful sunset")}
              className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
            >
              Generate Image
            </button>
            <span>•</span>
            <button 
              onClick={() => setShowFileUpload(true)}
              className="hover:text-purple-600 dark:hover:text-purple-400 transition-colors"
            >
              Upload File
            </button>
            <span>•</span>
            <button 
              onClick={onOpenTools}
              className="hover:text-green-600 dark:hover:text-green-400 transition-colors"
            >
              Open Tools
            </button>
          </div>
        )}
      </div>
    </div>
  );
};