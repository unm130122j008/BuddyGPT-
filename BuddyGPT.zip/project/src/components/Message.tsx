import React from 'react';
import { User, Bot, FileText, Image } from 'lucide-react';
import { Message as MessageType } from '../types';
import { MessageActions } from './MessageActions';
import { WeatherCard, NewsCard, CalculatorCard, ImageGenerationCard } from './PluginCards';

interface MessageProps {
  message: MessageType;
}

export const Message: React.FC<MessageProps> = ({ message }) => {
  const isUser = message.role === 'user';

  const handleFeedback = (messageId: string, type: 'like' | 'dislike') => {
    // Store feedback in localStorage for analytics
    const feedback = {
      messageId,
      type,
      timestamp: new Date().toISOString(),
      content: message.content.slice(0, 100) // Store first 100 chars for context
    };
    
    const existingFeedback = JSON.parse(localStorage.getItem('buddygpt-feedback') || '[]');
    existingFeedback.push(feedback);
    localStorage.setItem('buddygpt-feedback', JSON.stringify(existingFeedback));
    
    console.log(`Feedback received: ${type} for message ${messageId}`);
  };

  return (
    <div className={`group flex gap-4 p-4 animate-in slide-in-from-bottom-3 duration-300 ${
      isUser ? 'bg-transparent' : 'bg-gradient-to-r from-gray-50 to-blue-50/30 dark:from-gray-800/50 dark:to-blue-900/10'
    }`}>
      {/* Avatar */}
      <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transform transition-all duration-200 hover:scale-110 ${
        isUser 
          ? 'bg-gradient-to-br from-blue-500 to-blue-600 text-white shadow-lg' 
          : 'bg-gradient-to-br from-purple-500 via-blue-600 to-cyan-500 text-white shadow-lg'
      }`}>
        {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
      </div>

      {/* Message Content */}
      <div className="flex-1 space-y-2">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-sm bg-gradient-to-r from-gray-900 to-gray-700 dark:from-gray-100 dark:to-gray-300 bg-clip-text text-transparent">
            {isUser ? 'You' : 'BuddyGPT'}
          </span>
          <span className="text-xs text-gray-500 dark:text-gray-400">
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
        
        {/* File Attachment Display */}
        {message.fileInfo && (
          <div className="flex items-center gap-2 p-2 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg mb-2 animate-in fade-in duration-200">
            <div className="text-blue-600 dark:text-blue-400">
              {message.fileInfo.type.startsWith('image/') ? (
                <Image className="w-4 h-4" />
              ) : (
                <FileText className="w-4 h-4" />
              )}
            </div>
            <span className="text-sm font-medium text-blue-900 dark:text-blue-100">
              {message.fileInfo.name}
            </span>
            <span className="text-xs text-blue-600 dark:text-blue-400">
              ({message.fileInfo.size})
            </span>
          </div>
        )}
        
        {/* Plugin Data Display */}
        {message.pluginData && (
          <div className="animate-in fade-in duration-500">
            {message.pluginData.type === 'weather' && (
              <WeatherCard data={message.pluginData.data} />
            )}
            {message.pluginData.type === 'news' && (
              <NewsCard articles={message.pluginData.data} />
            )}
            {message.pluginData.type === 'calculator' && (
              <CalculatorCard result={message.pluginData.data} />
            )}
            {message.pluginData.type === 'image' && (
              <ImageGenerationCard 
                imageUrl={message.pluginData.data.imageUrl}
                prompt={message.pluginData.data.prompt}
                isLoading={message.pluginData.data.isLoading}
              />
            )}
          </div>
        )}
        
        <div className="prose prose-sm max-w-none dark:prose-invert">
          <p className="text-gray-800 dark:text-gray-200 whitespace-pre-wrap leading-relaxed animate-in fade-in duration-500">
            {message.content}
          </p>
        </div>

        {/* Message Actions - Only for AI responses */}
        {!isUser && (
          <MessageActions 
            messageContent={message.content}
            messageId={message.id}
            onFeedback={handleFeedback}
          />
        )}
      </div>
    </div>
  );
};