import React from 'react';
import { 
  Sparkles, 
  Mic, 
  Video, 
  Palette, 
  Brain, 
  FileText,
  Zap,
  Heart,
  Target,
  Coffee,
  Bot
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface EnhancedWelcomeScreenProps {
  onQuickStart: (prompt: string) => void;
}

export const EnhancedWelcomeScreen: React.FC<EnhancedWelcomeScreenProps> = ({ onQuickStart }) => {
  const { t } = useLanguage();

  const quickStartOptions = [
    {
      icon: <Palette className="w-6 h-6" />,
      title: "🎨 Generate Image",
      prompt: "Create a beautiful image of a sunset over mountains",
      gradient: "from-pink-500 to-orange-500"
    },
    {
      icon: <Brain className="w-6 h-6" />,
      title: "🧠 Ask Anything",
      prompt: "What's the most interesting fact about space?",
      gradient: "from-purple-500 to-blue-500"
    },
    {
      icon: <Video className="w-6 h-6" />,
      title: "📢 Voice to Video",
      prompt: "Help me create a short video script about AI technology",
      gradient: "from-green-500 to-teal-500"
    }
  ];

  const features = [
    {
      icon: "🌦️",
      title: t('weather'),
      description: t('weather_desc'),
      color: "bg-blue-50 dark:bg-blue-900/20"
    },
    {
      icon: "📰",
      title: t('news'),
      description: t('news_desc'),
      color: "bg-purple-50 dark:bg-purple-900/20"
    },
    {
      icon: "🧮",
      title: t('calculator'),
      description: t('calculator_desc'),
      color: "bg-green-50 dark:bg-green-900/20"
    },
    {
      icon: "📄",
      title: t('document_analyzer'),
      description: t('document_desc'),
      color: "bg-orange-50 dark:bg-orange-900/20"
    },
    {
      icon: "🎨",
      title: t('image_creator'),
      description: t('image_desc'),
      color: "bg-indigo-50 dark:bg-indigo-900/20"
    }
  ];

  return (
    <div className="flex items-center justify-center h-full bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-blue-900/20 dark:to-purple-900/20 overflow-y-auto">
      <div className="text-center animate-in fade-in duration-1000 max-w-4xl mx-auto p-8">
        {/* Animated Logo */}
        <div className="relative mb-8">
          <div className="w-24 h-24 bg-gradient-to-br from-purple-500 via-blue-600 to-cyan-500 rounded-xl mx-auto shadow-2xl animate-pulse flex items-center justify-center">
            <Bot className="w-12 h-12 text-white" />
          </div>
          <div className="absolute -top-2 -right-2 w-8 h-8 bg-green-400 rounded-full animate-bounce flex items-center justify-center">
            <span className="text-white text-sm">👋</span>
          </div>
          <div className="absolute -bottom-2 -left-2 w-6 h-6 bg-blue-500 rounded-full animate-pulse flex items-center justify-center">
            <Sparkles className="w-3 h-3 text-white" />
          </div>
        </div>

        {/* Welcome Message */}
        <div className="mb-8">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
            {t('welcome_title')}
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-2">
            {t('welcome_subtitle')}
          </p>
          <div className="flex items-center justify-center gap-6 text-sm text-purple-600 dark:text-purple-400 font-medium">
            <span className="flex items-center gap-1">
              <Coffee className="w-4 h-4" />
              24/7 Available
            </span>
            <span>🌍 All Languages</span>
            <span>🎯 Smart Suggestions</span>
            <span>🎤 Voice Support</span>
          </div>
        </div>

        {/* Quick Start Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {quickStartOptions.map((option, index) => (
            <button
              key={index}
              onClick={() => onQuickStart(option.prompt)}
              className={`group relative p-6 rounded-2xl bg-gradient-to-br ${option.gradient} hover:scale-105 transform transition-all duration-300 shadow-lg hover:shadow-xl text-white`}
            >
              <div className="flex flex-col items-center gap-3">
                <div className="p-3 bg-white/20 rounded-full group-hover:bg-white/30 transition-colors">
                  {option.icon}
                </div>
                <span className="font-semibold text-lg">{option.title}</span>
              </div>
              <div className="absolute inset-0 bg-white/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity"></div>
            </button>
          ))}
        </div>

        {/* Feature Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
          {features.map((feature, index) => (
            <div key={index} className={`${feature.color} backdrop-blur-sm p-4 rounded-xl hover:scale-105 transition-transform duration-200 cursor-pointer`}>
              <span className="text-2xl mb-2 block">{feature.icon}</span>
              <strong className="block text-sm font-semibold text-gray-800 dark:text-gray-200">
                {feature.title}
              </strong>
              <p className="text-xs mt-1 text-gray-600 dark:text-gray-400">
                {feature.description}
              </p>
            </div>
          ))}
        </div>

        {/* Simple Call to Action */}
        <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 rounded-2xl p-6 text-white">
          <h3 className="text-xl font-bold mb-2">Ready to get started? 🚀</h3>
          <p className="text-blue-100 mb-4">
            Just start typing below or try one of the quick actions above!
          </p>
          <div className="flex items-center justify-center gap-4 text-sm">
            <span className="flex items-center gap-1">
              <Mic className="w-4 h-4" />
              Voice Input
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <FileText className="w-4 h-4" />
              File Analysis
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Sparkles className="w-4 h-4" />
              Smart Suggestions
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};