import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, Clock, MessageSquare, Brain, Target } from 'lucide-react';
import { Message } from '../types';

interface ConversationInsightsProps {
  messages: Message[];
  isVisible: boolean;
  onClose: () => void;
}

export const ConversationInsights: React.FC<ConversationInsightsProps> = ({ messages, isVisible, onClose }) => {
  const [insights, setInsights] = useState<any>(null);

  useEffect(() => {
    if (messages.length > 0) {
      generateInsights();
    }
  }, [messages]);

  const generateInsights = () => {
    const userMessages = messages.filter(m => m.role === 'user');
    const aiMessages = messages.filter(m => m.role === 'assistant');
    
    // Conversation metrics
    const totalMessages = messages.length;
    const averageMessageLength = userMessages.reduce((sum, m) => sum + m.content.length, 0) / userMessages.length;
    
    // Time analysis
    const conversationDuration = messages.length > 1 
      ? messages[messages.length - 1].timestamp.getTime() - messages[0].timestamp.getTime()
      : 0;
    
    // Topic analysis
    const topics = analyzeTopics(userMessages);
    
    // Mood progression
    const moodProgression = analyzeMoodProgression(userMessages);
    
    // Engagement level
    const engagementLevel = calculateEngagement(userMessages);
    
    // Learning patterns
    const learningPatterns = analyzeLearningPatterns(userMessages);

    setInsights({
      totalMessages,
      averageMessageLength: Math.round(averageMessageLength),
      conversationDuration: Math.round(conversationDuration / 1000 / 60), // minutes
      topics,
      moodProgression,
      engagementLevel,
      learningPatterns,
      userToAiRatio: userMessages.length / aiMessages.length
    });
  };

  const analyzeTopics = (messages: Message[]) => {
    const topicKeywords = {
      'Technology': ['ai', 'computer', 'software', 'tech', 'programming', 'code', 'digital'],
      'Creative': ['art', 'design', 'creative', 'music', 'story', 'write', 'imagine'],
      'Learning': ['learn', 'study', 'understand', 'explain', 'teach', 'knowledge'],
      'Personal': ['feel', 'think', 'life', 'personal', 'experience', 'emotion'],
      'Work': ['work', 'job', 'career', 'business', 'professional', 'project'],
      'Health': ['health', 'fitness', 'exercise', 'wellness', 'medical', 'body']
    };

    const topicCounts: { [key: string]: number } = {};
    
    Object.keys(topicKeywords).forEach(topic => {
      topicCounts[topic] = 0;
      messages.forEach(message => {
        const content = message.content.toLowerCase();
        topicKeywords[topic].forEach(keyword => {
          if (content.includes(keyword)) {
            topicCounts[topic]++;
          }
        });
      });
    });

    return Object.entries(topicCounts)
      .sort(([,a], [,b]) => b - a)
      .slice(0, 3)
      .map(([topic, count]) => ({ topic, count }));
  };

  const analyzeMoodProgression = (messages: Message[]) => {
    const moods = messages.map(message => {
      const content = message.content.toLowerCase();
      if (content.includes('happy') || content.includes('great') || content.includes('awesome')) return 'positive';
      if (content.includes('sad') || content.includes('frustrated') || content.includes('angry')) return 'negative';
      return 'neutral';
    });

    const positive = moods.filter(m => m === 'positive').length;
    const negative = moods.filter(m => m === 'negative').length;
    const neutral = moods.filter(m => m === 'neutral').length;

    return { positive, negative, neutral };
  };

  const calculateEngagement = (messages: Message[]) => {
    const avgLength = messages.reduce((sum, m) => sum + m.content.length, 0) / messages.length;
    const questionCount = messages.filter(m => m.content.includes('?')).length;
    const exclamationCount = messages.filter(m => m.content.includes('!')).length;
    
    const score = Math.min(100, (avgLength / 10) + (questionCount * 5) + (exclamationCount * 3));
    return Math.round(score);
  };

  const analyzeLearningPatterns = (messages: Message[]) => {
    const learningIndicators = ['how', 'what', 'why', 'explain', 'teach', 'learn', 'understand'];
    const learningMessages = messages.filter(m => 
      learningIndicators.some(indicator => m.content.toLowerCase().includes(indicator))
    );
    
    return {
      learningQuestions: learningMessages.length,
      curiosityLevel: Math.round((learningMessages.length / messages.length) * 100)
    };
  };

  if (!isVisible || !insights) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BarChart3 className="w-6 h-6 text-purple-600" />
              <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100">
                Conversation Insights
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Overview Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
              <MessageSquare className="w-5 h-5 text-blue-600 mb-2" />
              <div className="text-2xl font-bold text-blue-600">{insights.totalMessages}</div>
              <div className="text-sm text-blue-600/70">Total Messages</div>
            </div>
            
            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
              <Clock className="w-5 h-5 text-green-600 mb-2" />
              <div className="text-2xl font-bold text-green-600">{insights.conversationDuration}m</div>
              <div className="text-sm text-green-600/70">Duration</div>
            </div>
            
            <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg">
              <Brain className="w-5 h-5 text-purple-600 mb-2" />
              <div className="text-2xl font-bold text-purple-600">{insights.engagementLevel}%</div>
              <div className="text-sm text-purple-600/70">Engagement</div>
            </div>
            
            <div className="bg-orange-50 dark:bg-orange-900/20 p-4 rounded-lg">
              <Target className="w-5 h-5 text-orange-600 mb-2" />
              <div className="text-2xl font-bold text-orange-600">{insights.learningPatterns.curiosityLevel}%</div>
              <div className="text-sm text-orange-600/70">Curiosity</div>
            </div>
          </div>

          {/* Top Topics */}
          <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">Top Discussion Topics</h3>
            <div className="space-y-2">
              {insights.topics.map((topic: any, index: number) => (
                <div key={topic.topic} className="flex items-center justify-between">
                  <span className="text-sm text-gray-700 dark:text-gray-300">{topic.topic}</span>
                  <div className="flex items-center gap-2">
                    <div className="w-20 h-2 bg-gray-200 dark:bg-gray-600 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-500"
                        style={{ width: `${(topic.count / insights.topics[0].count) * 100}%` }}
                      />
                    </div>
                    <span className="text-xs text-gray-500 w-6">{topic.count}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Mood Analysis */}
          <div className="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">Mood Distribution</h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">{insights.moodProgression.positive}</div>
                <div className="text-sm text-green-600">Positive</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-600">{insights.moodProgression.neutral}</div>
                <div className="text-sm text-gray-600">Neutral</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600">{insights.moodProgression.negative}</div>
                <div className="text-sm text-red-600">Negative</div>
              </div>
            </div>
          </div>

          {/* Learning Insights */}
          <div className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 p-4 rounded-lg">
            <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">Learning Patterns</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-lg font-bold text-purple-600">{insights.learningPatterns.learningQuestions}</div>
                <div className="text-sm text-purple-600/70">Learning Questions Asked</div>
              </div>
              <div>
                <div className="text-lg font-bold text-blue-600">{insights.averageMessageLength}</div>
                <div className="text-sm text-blue-600/70">Avg. Message Length</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};