import React, { useState } from 'react';
import { Bot, Sparkles, MessageCircle, Zap, Heart, Star, Rocket } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

export const LoginScreen: React.FC = () => {
  const [userName, setUserName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { loginWithName } = useAuth();

  const handleNameSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim()) return;

    setIsLoading(true);
    try {
      await loginWithName(userName.trim());
    } catch (error) {
      console.error('Error setting user name:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const samplePrompts = [
    "What should I eat today? 🍕",
    "Give me a joke! 😄",
    "Help me write a resume 📝"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 dark:from-gray-900 dark:via-blue-900/20 dark:to-purple-900/20 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Floating Bot Icons */}
        <div className="absolute top-20 left-10 animate-bounce" style={{ animationDelay: '0s', animationDuration: '3s' }}>
          <Bot className="w-8 h-8 text-blue-400/30" />
        </div>
        <div className="absolute top-40 right-20 animate-bounce" style={{ animationDelay: '1s', animationDuration: '4s' }}>
          <MessageCircle className="w-6 h-6 text-purple-400/30" />
        </div>
        <div className="absolute bottom-40 left-20 animate-bounce" style={{ animationDelay: '2s', animationDuration: '3.5s' }}>
          <Sparkles className="w-7 h-7 text-pink-400/30" />
        </div>
        <div className="absolute top-60 left-1/3 animate-bounce" style={{ animationDelay: '0.5s', animationDuration: '4.5s' }}>
          <Zap className="w-5 h-5 text-cyan-400/30" />
        </div>
        <div className="absolute bottom-60 right-1/4 animate-bounce" style={{ animationDelay: '1.5s', animationDuration: '3.2s' }}>
          <Heart className="w-6 h-6 text-red-400/30" />
        </div>
        
        {/* Floating Stars */}
        {[...Array(12)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-pulse"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}
          >
            <Star className="w-3 h-3 text-yellow-400/20" />
          </div>
        ))}
        
        {/* Gradient Orbs */}
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-gradient-to-r from-blue-400/10 to-purple-400/10 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '4s' }}></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-gradient-to-r from-pink-400/10 to-cyan-400/10 rounded-full blur-3xl animate-pulse" style={{ animationDuration: '5s', animationDelay: '2s' }}></div>
      </div>

      <div className="relative z-10 flex items-center justify-center min-h-screen p-4">
        <div className="max-w-2xl w-full text-center animate-in fade-in duration-1000">
          {/* Hero Section */}
          <div className="mb-12">
            {/* Animated Logo */}
            <div className="relative mb-8">
              <div className="w-24 h-24 bg-gradient-to-br from-purple-500 via-blue-600 to-cyan-500 rounded-xl mx-auto shadow-2xl flex items-center justify-center animate-pulse">
                <Bot className="w-12 h-12 text-white" />
              </div>
              <div className="absolute -top-2 -right-2 w-8 h-8 bg-green-400 rounded-full animate-bounce flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div className="absolute -bottom-2 -left-2 w-6 h-6 bg-pink-500 rounded-full animate-pulse flex items-center justify-center">
                <Heart className="w-3 h-3 text-white" />
              </div>
            </div>

            {/* Logo Text */}
            <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-4 animate-in slide-in-from-bottom-4 duration-700">
              BuddyGPT
            </h1>

            {/* Animated Tagline */}
            <div className="mb-8 animate-in slide-in-from-bottom-5 duration-900">
              <p className="text-2xl text-gray-600 dark:text-gray-400 mb-2">
                Your friendly AI buddy, ready to chat with you ✨
              </p>
              <div className="flex items-center justify-center gap-2 text-sm text-purple-600 dark:text-purple-400 font-medium">
                <div className="flex items-center gap-1 animate-pulse">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span>Online</span>
                </div>
                <span>•</span>
                <span>🌍 All Languages</span>
                <span>•</span>
                <span>🎯 Smart & Fun</span>
              </div>
            </div>

            {/* Typing Animation */}
            <div className="mb-8 animate-in slide-in-from-bottom-6 duration-1100">
              <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl p-4 max-w-md mx-auto border border-gray-200 dark:border-gray-700 shadow-lg">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
                    <Bot className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm font-medium text-gray-900 dark:text-gray-100 mb-1">BuddyGPT</div>
                    <div className="flex items-center gap-1">
                      <span className="text-gray-600 dark:text-gray-400 text-sm">Hi! I'm BuddyGPT. What's your name?</span>
                      <div className="flex space-x-1 ml-2">
                        <div className="w-1 h-1 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                        <div className="w-1 h-1 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                        <div className="w-1 h-1 bg-pink-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Name Input Form */}
          <div className="mb-12 animate-in slide-in-from-bottom-7 duration-1300">
            <form onSubmit={handleNameSubmit} className="max-w-md mx-auto">
              <div className="flex gap-3">
                <div className="flex-1">
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="Your name"
                    className="w-full px-6 py-4 text-lg rounded-2xl border-2 border-gray-200 dark:border-gray-600 bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm text-gray-900 dark:text-gray-100 placeholder-gray-500 dark:placeholder-gray-400 focus:border-blue-500 focus:ring-4 focus:ring-blue-500/20 transition-all duration-200 shadow-lg"
                    disabled={isLoading}
                    autoFocus
                  />
                </div>
                <button
                  type="submit"
                  disabled={!userName.trim() || isLoading}
                  className="px-6 py-4 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 hover:from-blue-700 hover:via-purple-700 hover:to-pink-700 disabled:from-gray-300 disabled:via-gray-300 disabled:to-gray-300 dark:disabled:from-gray-600 dark:disabled:via-gray-600 dark:disabled:to-gray-600 text-white rounded-2xl transition-all duration-200 focus:outline-none focus:ring-4 focus:ring-blue-500/20 disabled:cursor-not-allowed transform hover:scale-105 active:scale-95 shadow-lg flex items-center gap-2"
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <Rocket className="w-5 h-5" />
                      <span className="font-semibold">Start Chat</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>

          {/* Sample Prompts */}
          <div className="mb-12 animate-in slide-in-from-bottom-8 duration-1500">
            <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-4">
              Try asking me:
            </h3>
            <div className="flex flex-wrap justify-center gap-3">
              {samplePrompts.map((prompt, index) => (
                <div
                  key={index}
                  className="px-4 py-2 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm rounded-full border border-gray-200 dark:border-gray-600 text-gray-700 dark:text-gray-300 text-sm hover:bg-white/80 dark:hover:bg-gray-800/80 transition-all duration-200 cursor-pointer transform hover:scale-105 shadow-md"
                  style={{ animationDelay: `${index * 200}ms` }}
                >
                  {prompt}
                </div>
              ))}
            </div>
          </div>

          {/* Features Section */}
          <div className="mb-12 animate-in slide-in-from-bottom-9 duration-1700">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm p-6 rounded-2xl border border-gray-200 dark:border-gray-600 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                <MessageCircle className="w-8 h-8 text-blue-600 mb-3 mx-auto" />
                <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Talk</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">Natural conversations in any language</p>
              </div>
              
              <div className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm p-6 rounded-2xl border border-gray-200 dark:border-gray-600 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105" style={{ animationDelay: '200ms' }}>
                <Zap className="w-8 h-8 text-purple-600 mb-3 mx-auto" />
                <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Learn</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">Get answers and explanations instantly</p>
              </div>
              
              <div className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm p-6 rounded-2xl border border-gray-200 dark:border-gray-600 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105" style={{ animationDelay: '400ms' }}>
                <Sparkles className="w-8 h-8 text-pink-600 mb-3 mx-auto" />
                <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Create</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400">Generate content, ideas, and solutions</p>
              </div>
            </div>
          </div>

          {/* About Section */}
          <div className="mb-8 animate-in slide-in-from-bottom-10 duration-1900">
            <div className="bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-pink-600/10 backdrop-blur-sm rounded-2xl p-6 border border-gray-200 dark:border-gray-600 shadow-lg">
              <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2 flex items-center justify-center gap-2">
                <Bot className="w-5 h-5 text-purple-600" />
                Powered by Advanced AI
              </h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Trained to be your helpful buddy. Smart, friendly, and always ready to assist with anything you need.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Clean Simple Footer */}
      <div className="absolute bottom-0 left-0 right-0 p-4 text-center animate-in fade-in duration-2000">
        <p className="text-xs text-gray-500 dark:text-gray-400">
          Made with ❤️ by Bob • © 2025 BuddyGPT
        </p>
      </div>
    </div>
  );
};