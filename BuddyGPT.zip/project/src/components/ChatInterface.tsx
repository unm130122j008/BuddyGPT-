import React, { useEffect, useRef, useState } from 'react';
import { Menu, X, BarChart3, User, Bot, EyeOff } from 'lucide-react';
import { useChat } from '../contexts/ChatContext';
import { useIncognito } from '../contexts/IncognitoContext';
import { Message } from './Message';
import { MessageInput } from './MessageInput';
import { EnhancedTypingIndicator } from './EnhancedTypingIndicator';
import { Sidebar } from './Sidebar';
import { EnhancedWelcomeScreen } from './EnhancedWelcomeScreen';
import { SmartSuggestions } from './SmartSuggestions';
import { ContextualMemory } from './ContextualMemory';
import { ConversationInsights } from './ConversationInsights';
import { UserProfile } from './UserProfile';
import { ToolsPanel } from './ToolsPanel';
import { MotivationalQuotes } from './MotivationalQuotes';
import { BackToTopButton } from './BackToTopButton';
import { InfiniteScrollLoader } from './InfiniteScrollLoader';
import { useInfiniteScroll } from '../hooks/useInfiniteScroll';
import { useVoiceOutput } from '../hooks/useVoiceOutput';

export const ChatInterface: React.FC = () => {
  const { currentChat, isTyping, sendMessage, lastUserMessage, hasRecentActivity, chats } = useChat();
  const { isIncognitoMode } = useIncognito();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showInsights, setShowInsights] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const [showTools, setShowTools] = useState(false);
  const [relevantMemories, setRelevantMemories] = useState<any[]>([]);
  const [shouldAutoScroll, setShouldAutoScroll] = useState(true);
  const { speak } = useVoiceOutput();

  // Infinite scroll hook
  const { displayedMessages, isLoading, hasMore } = useInfiniteScroll({
    messages: currentChat?.messages || [],
    scrollContainerRef: messagesContainerRef,
    itemsPerPage: 20
  });

  // Auto-scroll to bottom when new messages arrive (only if user is near bottom)
  useEffect(() => {
    if (!messagesContainerRef.current || !shouldAutoScroll) return;

    const container = messagesContainerRef.current;
    const { scrollTop, scrollHeight, clientHeight } = container;
    const isNearBottom = scrollHeight - scrollTop - clientHeight < 200;

    if (isNearBottom || isTyping) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [displayedMessages, isTyping, shouldAutoScroll]);

  // Monitor scroll position to determine auto-scroll behavior
  useEffect(() => {
    const container = messagesContainerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      const isNearBottom = scrollHeight - scrollTop - clientHeight < 200;
      setShouldAutoScroll(isNearBottom);
    };

    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  // Speak AI responses if TTS is enabled
  useEffect(() => {
    if (currentChat?.messages.length > 0) {
      const lastMessage = currentChat.messages[currentChat.messages.length - 1];
      if (lastMessage.role === 'assistant') {
        speak(lastMessage.content);
      }
    }
  }, [currentChat?.messages, speak]);

  const handleQuickStart = async (prompt: string) => {
    await sendMessage(prompt);
  };

  const handleSuggestionClick = async (suggestion: string) => {
    await sendMessage(suggestion);
  };

  const handleMemoryRecall = (memories: any[]) => {
    setRelevantMemories(memories);
  };

  const handleToolSelect = async (tool: string, data: any) => {
    let message = '';
    switch (tool) {
      case 'weather':
        message = `Show me the weather for ${data.location}`;
        break;
      case 'news':
        message = data.query ? `Show me news about ${data.query}` : 'Show me the latest news';
        break;
      case 'calculator':
        message = `Calculate: ${data.expression}`;
        break;
      default:
        message = `Use ${tool} tool`;
    }
    await sendMessage(message);
  };

  if (!currentChat) {
    return (
      <div className="flex h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30 dark:from-gray-900 dark:via-blue-900/10 dark:to-purple-900/10">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
        <div className="flex-1">
          <EnhancedWelcomeScreen onQuickStart={handleQuickStart} />
        </div>
        <UserProfile isOpen={showProfile} onClose={() => setShowProfile(false)} />
        <ToolsPanel 
          isOpen={showTools} 
          onClose={() => setShowTools(false)}
          onToolSelect={handleToolSelect}
        />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30 dark:from-gray-900 dark:via-blue-900/10 dark:to-purple-900/10">
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      
      <div className="flex-1 flex flex-col min-w-0 relative">
        {/* Enhanced Header with Motivational Quote */}
        <div className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm">
          {/* Motivational Quote Bar */}
          <div className="px-4 py-2 border-b border-gray-100 dark:border-gray-800">
            <MotivationalQuotes />
          </div>
          
          {/* Main Header */}
          <div className="px-4 py-3">
            <div className="flex items-center gap-3">
              <button
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
              >
                <Menu className="w-5 h-5 text-gray-600 dark:text-gray-300" />
              </button>
              
              <div className="flex items-center gap-3 flex-1">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 via-blue-600 to-cyan-500 flex items-center justify-center shadow-lg relative">
                  <Bot className="w-5 h-5 text-white" />
                  {isIncognitoMode && (
                    <div className="absolute -top-1 -right-1 w-3 h-3 bg-purple-600 rounded-full flex items-center justify-center">
                      <EyeOff className="w-2 h-2 text-white" />
                    </div>
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="font-semibold text-gray-900 dark:text-gray-100 truncate">
                      {currentChat.title}
                    </h2>
                    {isIncognitoMode && (
                      <span className="px-2 py-0.5 bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300 text-xs rounded-full font-medium">
                        Incognito
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {currentChat.messages.length} messages • BuddyGPT Active ✨
                    </p>
                  </div>
                </div>
              </div>

              {/* Header Actions */}
              <div className="flex items-center gap-2">
                {!isIncognitoMode && (
                  <button
                    onClick={() => setShowInsights(true)}
                    className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
                    title="View Conversation Insights"
                  >
                    <BarChart3 className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                  </button>
                )}

                <button
                  onClick={() => setShowProfile(true)}
                  className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors duration-200"
                  title="User Profile"
                >
                  <User className="w-5 h-5 text-gray-600 dark:text-gray-300" />
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Messages with Infinite Scroll */}
        <div 
          ref={messagesContainerRef}
          className="flex-1 overflow-y-auto chat-scroll"
        >
          <div className="max-w-4xl mx-auto">
            {currentChat.messages.length === 0 ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center py-12 animate-in fade-in duration-1000 max-w-2xl mx-auto px-4">
                  <div className="relative mb-6">
                    <div className="w-16 h-16 rounded-xl mx-auto shadow-xl bg-gradient-to-br from-purple-500 via-blue-600 to-cyan-500 flex items-center justify-center">
                      <Bot className="w-8 h-8 text-white" />
                    </div>
                    <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-400 rounded-full animate-pulse"></div>
                    {isIncognitoMode && (
                      <div className="absolute -bottom-1 -left-1 w-5 h-5 bg-purple-600 rounded-full flex items-center justify-center">
                        <EyeOff className="w-3 h-3 text-white" />
                      </div>
                    )}
                  </div>
                  <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-3">
                    Hey there! I'm BuddyGPT 👋
                  </h3>
                  {isIncognitoMode && (
                    <div className="mb-4 p-3 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-700 rounded-lg">
                      <p className="text-sm text-purple-700 dark:text-purple-300 font-medium">
                        🔒 Incognito Mode Active - Your conversations won't be saved
                      </p>
                    </div>
                  )}
                  <div className="text-gray-600 dark:text-gray-400 max-w-lg mx-auto space-y-2">
                    <p className="leading-relaxed">
                      Ready to chat, create, or help with something cool? ✨
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-6 text-sm">
                      <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                        <span className="text-2xl mb-2 block">🌦️</span>
                        <strong>Weather Updates</strong>
                        <p className="text-xs mt-1">Get current weather for any location</p>
                      </div>
                      <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg">
                        <span className="text-2xl mb-2 block">📰</span>
                        <strong>Latest News</strong>
                        <p className="text-xs mt-1">Stay updated with breaking news</p>
                      </div>
                      <div className="bg-green-50 dark:bg-green-900/20 p-3 rounded-lg">
                        <span className="text-2xl mb-2 block">🧮</span>
                        <strong>Smart Calculator</strong>
                        <p className="text-xs mt-1">Solve complex mathematical problems</p>
                      </div>
                    </div>
                    <p className="text-sm font-medium text-purple-600 dark:text-purple-400 mt-4">
                      🌍 I speak all languages fluently - chat in your preferred language!
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <>
                {/* Infinite Scroll Loader at Top */}
                <InfiniteScrollLoader isLoading={isLoading} hasMore={hasMore} />

                {/* Contextual Memory Display - Only in normal mode */}
                {!isIncognitoMode && lastUserMessage && (
                  <div className="p-4">
                    <ContextualMemory 
                      currentMessage={lastUserMessage}
                      onMemoryRecall={handleMemoryRecall}
                    />
                  </div>
                )}

                {/* Messages */}
                {displayedMessages.map((message) => (
                  <Message key={message.id} message={message} />
                ))}
                
                {/* Typing Indicator */}
                {isTyping && <EnhancedTypingIndicator />}
                
                {/* Smart Suggestions - Only in normal mode */}
                {!isIncognitoMode && !isTyping && lastUserMessage && hasRecentActivity() && (
                  <div className="p-4 space-y-3">
                    <SmartSuggestions 
                      lastMessage={lastUserMessage}
                      onSuggestionClick={handleSuggestionClick}
                    />
                  </div>
                )}
              </>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Back to Top Button */}
        <BackToTopButton scrollContainerRef={messagesContainerRef} />

        {/* Input */}
        <MessageInput onOpenTools={() => setShowTools(true)} />
      </div>

      {/* Modals */}
      {!isIncognitoMode && (
        <ConversationInsights 
          messages={currentChat.messages}
          isVisible={showInsights}
          onClose={() => setShowInsights(false)}
        />
      )}
      
      <UserProfile 
        isOpen={showProfile} 
        onClose={() => setShowProfile(false)} 
      />
      
      <ToolsPanel 
        isOpen={showTools} 
        onClose={() => setShowTools(false)}
        onToolSelect={handleToolSelect}
      />
    </div>
  );
};