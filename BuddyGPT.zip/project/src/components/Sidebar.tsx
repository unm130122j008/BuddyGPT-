import React from 'react';
import { Plus, MessageSquare, Trash2, BarChart3, Bot } from 'lucide-react';
import { useChat } from '../contexts/ChatContext';
import { useLanguage } from '../contexts/LanguageContext';
import { ThemeToggle } from './ThemeToggle';

export const Sidebar: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { chats, currentChat, createNewChat, selectChat, deleteChat } = useChat();
  const { t } = useLanguage();

  const handleNewChat = () => {
    createNewChat();
    onClose();
  };

  const handleSelectChat = (chatId: string) => {
    selectChat(chatId);
    onClose();
  };

  // Calculate total messages across all chats
  const totalMessages = chats.reduce((sum, chat) => sum + chat.messages.length, 0);
  const totalChats = chats.length;

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-50 w-80 bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm border-r border-gray-200 dark:border-gray-700 transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 via-blue-600 to-cyan-500 flex items-center justify-center shadow-lg">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                  {t('buddygpt')}
                </h1>
              </div>
              <ThemeToggle />
            </div>
            
            <button
              onClick={handleNewChat}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 dark:focus:ring-offset-gray-900 shadow-lg transform hover:scale-105 active:scale-95"
            >
              <Plus className="w-5 h-5" />
              {t('new_chat')}
            </button>
          </div>

          {/* Stats Overview */}
          <div className="p-4 border-b border-gray-200 dark:border-gray-700">
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded-lg">
                <div className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-blue-600" />
                  <span className="text-xs text-blue-600 font-medium">{t('total_messages')}</span>
                </div>
                <div className="text-lg font-bold text-blue-600">{totalMessages}</div>
              </div>
              <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg">
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-purple-600" />
                  <span className="text-xs text-purple-600 font-medium">{t('total_chats')}</span>
                </div>
                <div className="text-lg font-bold text-purple-600">{totalChats}</div>
              </div>
            </div>
          </div>

          {/* Chat List with Custom Scrollbar */}
          <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scroll">
            {chats.map((chat) => (
              <div
                key={chat.id}
                className={`
                  group relative flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all duration-200
                  ${currentChat?.id === chat.id 
                    ? 'bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border border-blue-200 dark:border-blue-700 shadow-sm' 
                    : 'hover:bg-gray-50 dark:hover:bg-gray-800'
                  }
                `}
                onClick={() => handleSelectChat(chat.id)}
              >
                <MessageSquare className={`w-4 h-4 flex-shrink-0 ${
                  currentChat?.id === chat.id ? 'text-blue-600 dark:text-blue-400' : 'text-gray-400'
                }`} />
                
                <div className="flex-1 min-w-0">
                  <p className={`text-sm font-medium truncate ${
                    currentChat?.id === chat.id 
                      ? 'text-blue-900 dark:text-blue-100' 
                      : 'text-gray-900 dark:text-gray-100'
                  }`}>
                    {chat.title}
                  </p>
                  <div className="flex items-center gap-2">
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {chat.messages.length} {t('messages')}
                    </p>
                    {chat.messages.length > 10 && (
                      <span className="px-1.5 py-0.5 bg-green-100 text-green-600 text-xs rounded-full">
                        {t('active')}
                      </span>
                    )}
                  </div>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteChat(chat.id);
                  }}
                  className="opacity-0 group-hover:opacity-100 p-1 rounded text-gray-400 hover:text-red-500 transition-all duration-200"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>

          {/* Footer */}
          <div className="p-4 border-t border-gray-200 dark:border-gray-700">
            <div className="text-center space-y-2">
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {t('buddygpt')} v2.0 • Enhanced with AI Features
              </p>
              <div className="flex justify-center gap-4 text-xs text-gray-400">
                <span className="flex items-center gap-1">
                  🧠 Smart Memory
                </span>
                <span className="flex items-center gap-1">
                  📊 Insights
                </span>
                <span className="flex items-center gap-1">
                  💾 Auto-Save
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};