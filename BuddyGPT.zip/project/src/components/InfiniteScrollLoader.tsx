import React from 'react';
import { Loader2, Sparkles } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface InfiniteScrollLoaderProps {
  isLoading: boolean;
  hasMore: boolean;
}

export const InfiniteScrollLoader: React.FC<InfiniteScrollLoaderProps> = ({ isLoading, hasMore }) => {
  const { t } = useLanguage();

  if (!hasMore && !isLoading) return null;

  return (
    <div className="flex items-center justify-center py-6 animate-in fade-in duration-300">
      {isLoading ? (
        <div className="flex items-center gap-3 text-gray-500 dark:text-gray-400">
          <Loader2 className="w-5 h-5 animate-spin" />
          <span className="text-sm font-medium">{t('loading_messages')}</span>
        </div>
      ) : hasMore ? (
        <div className="flex items-center gap-3 text-purple-600 dark:text-purple-400">
          <Sparkles className="w-5 h-5" />
          <span className="text-sm font-medium">{t('scroll_load_more')}</span>
        </div>
      ) : (
        <div className="text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-full border border-blue-200 dark:border-blue-700">
            <Sparkles className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <span className="text-sm font-medium text-purple-600 dark:text-purple-400">
              {t('conversation_beginning')}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};