import React, { useState } from 'react';
import { 
  Cloud, 
  Calculator, 
  Palette, 
  Settings,
  X,
  ChevronRight,
  Video,
  PenTool,
  ExternalLink,
  Eraser
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { pluginService } from '../services/pluginService';

interface ToolsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onToolSelect: (tool: string, data?: any) => void;
}

export const ToolsPanel: React.FC<ToolsPanelProps> = ({ isOpen, onClose, onToolSelect }) => {
  const [activeSection, setActiveSection] = useState<string | null>(null);
  const [weatherLocation, setWeatherLocation] = useState('');
  const [calcExpression, setCalcExpression] = useState('');
  const { t } = useLanguage();

  const tools = [
    {
      id: 'weather',
      name: t('weather'),
      icon: <Cloud className="w-5 h-5" />,
      color: 'from-blue-500 to-cyan-500',
      description: 'Real-time weather powered by AccuWeather'
    },
    {
      id: 'calculator',
      name: t('calculator'),
      icon: <Calculator className="w-5 h-5" />,
      color: 'from-green-500 to-emerald-500',
      description: t('calculator_tool_desc')
    },
    {
      id: 'image',
      name: 'AI Image Creator',
      icon: <Palette className="w-5 h-5" />,
      color: 'from-pink-500 to-rose-500',
      description: 'Create stunning images with Imagine.art'
    },
    {
      id: 'pixerase',
      name: 'PixErase',
      icon: <Eraser className="w-5 h-5" />,
      color: 'from-red-500 to-orange-500',
      description: 'Remove backgrounds from images instantly'
    },
    {
      id: 'video',
      name: 'Video Generator',
      icon: <Video className="w-5 h-5" />,
      color: 'from-purple-500 to-indigo-500',
      description: 'Create professional videos with Jitter'
    },
    {
      id: 'writing',
      name: 'AI Writing Assistant',
      icon: <PenTool className="w-5 h-5" />,
      color: 'from-orange-500 to-amber-500',
      description: 'Professional writing with GravityWrite'
    }
  ];

  const handleWeatherSubmit = async () => {
    if (weatherLocation.trim()) {
      const weatherData = await pluginService.getWeather(weatherLocation);
      onToolSelect('weather', weatherData);
      setWeatherLocation('');
      setActiveSection(null);
      onClose();
    }
  };

  const handleCalculatorSubmit = () => {
    if (calcExpression.trim()) {
      const result = pluginService.calculate(calcExpression);
      onToolSelect('calculator', result);
      setCalcExpression('');
      setActiveSection(null);
      onClose();
    }
  };

  const handleExternalTool = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
    setActiveSection(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="fixed inset-0 bg-black/50 z-40" onClick={onClose} />
      <div className="fixed left-4 top-1/2 -translate-y-1/2 w-80 bg-white dark:bg-gray-800 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 z-50 animate-in slide-in-from-left-2 duration-300">
        {/* Header */}
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Settings className="w-5 h-5 text-purple-600" />
              <h2 className="font-semibold text-gray-900 dark:text-gray-100">{t('tools')}</h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            >
              <X className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        </div>

        {/* Tools List */}
        <div className="p-4 space-y-3 max-h-96 overflow-y-auto">
          {tools.map((tool) => (
            <div key={tool.id} className="space-y-2">
              <button
                onClick={() => {
                  if (tool.id === 'image') {
                    handleExternalTool('https://www.imagine.art/dashboard/image/tool/text-to-image');
                  } else if (tool.id === 'pixerase') {
                    handleExternalTool('https://loquacious-llama-59b698.netlify.app/');
                  } else if (tool.id === 'video') {
                    handleExternalTool('https://jitter.video/files/');
                  } else if (tool.id === 'writing') {
                    handleExternalTool('https://gravitywrite.com/');
                  } else {
                    setActiveSection(activeSection === tool.id ? null : tool.id);
                  }
                }}
                className={`w-full flex items-center gap-3 p-3 rounded-lg transition-all duration-200 ${
                  activeSection === tool.id
                    ? 'bg-gradient-to-r ' + tool.color + ' text-white shadow-lg'
                    : 'hover:bg-gray-50 dark:hover:bg-gray-700 border border-gray-200 dark:border-gray-600'
                }`}
              >
                <div className={`p-2 rounded-lg ${
                  activeSection === tool.id 
                    ? 'bg-white/20' 
                    : 'bg-gradient-to-r ' + tool.color + ' text-white'
                }`}>
                  {tool.icon}
                </div>
                <div className="flex-1 text-left">
                  <h3 className={`font-medium ${
                    activeSection === tool.id ? 'text-white' : 'text-gray-900 dark:text-gray-100'
                  }`}>
                    {tool.name}
                  </h3>
                  <p className={`text-xs ${
                    activeSection === tool.id ? 'text-white/80' : 'text-gray-500 dark:text-gray-400'
                  }`}>
                    {tool.description}
                  </p>
                </div>
                {['image', 'pixerase', 'video', 'writing'].includes(tool.id) ? (
                  <ExternalLink className={`w-4 h-4 ${
                    activeSection === tool.id ? 'text-white' : 'text-gray-400'
                  }`} />
                ) : (
                  <ChevronRight className={`w-4 h-4 transition-transform ${
                    activeSection === tool.id ? 'rotate-90 text-white' : 'text-gray-400'
                  }`} />
                )}
              </button>

              {/* Tool-specific forms */}
              {activeSection === tool.id && ['weather', 'calculator'].includes(tool.id) && (
                <div className="ml-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg animate-in slide-in-from-top-2 duration-200">
                  {tool.id === 'weather' && (
                    <div className="space-y-3">
                      <input
                        type="text"
                        placeholder="Enter city name..."
                        value={weatherLocation}
                        onChange={(e) => setWeatherLocation(e.target.value)}
                        className="w-full p-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        onKeyPress={(e) => e.key === 'Enter' && handleWeatherSubmit()}
                      />
                      <button
                        onClick={handleWeatherSubmit}
                        className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                      >
                        Get Weather
                      </button>
                    </div>
                  )}

                  {tool.id === 'calculator' && (
                    <div className="space-y-3">
                      <input
                        type="text"
                        placeholder="Enter expression (e.g., 2+2*3)..."
                        value={calcExpression}
                        onChange={(e) => setCalcExpression(e.target.value)}
                        className="w-full p-2 border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-green-500 focus:border-transparent"
                        onKeyPress={(e) => e.key === 'Enter' && handleCalculatorSubmit()}
                      />
                      <button
                        onClick={handleCalculatorSubmit}
                        className="w-full py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
                      >
                        Calculate
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200 dark:border-gray-700">
          <div className="text-center">
            <p className="text-xs text-gray-500 dark:text-gray-400">
              🚀 Professional tools powered by leading AI services
            </p>
          </div>
        </div>
      </div>
    </>
  );
};