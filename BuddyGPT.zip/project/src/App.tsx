import React from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { IncognitoProvider } from './contexts/IncognitoContext';
import { AuthProvider } from './contexts/AuthContext';
import { ChatProvider } from './contexts/ChatContext';
import { ChatInterface } from './components/ChatInterface';
import { LoginScreen } from './components/LoginScreen';
import { useAuth } from './contexts/AuthContext';

const AppContent: React.FC = () => {
  const { currentUser } = useAuth();

  if (!currentUser) {
    return <LoginScreen />;
  }

  return (
    <IncognitoProvider>
      <LanguageProvider>
        <ChatProvider>
          <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
            <ChatInterface />
          </div>
        </ChatProvider>
      </LanguageProvider>
    </IncognitoProvider>
  );
};

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;