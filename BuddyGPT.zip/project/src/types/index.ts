export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  fileInfo?: {
    name: string;
    type: string;
    size: string;
  };
  pluginData?: {
    type: 'weather' | 'news' | 'calculator' | 'image';
    data: any;
  };
}

export interface Chat {
  id: string;
  title: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
}

export type Theme = 'light' | 'dark';

export interface WeatherData {
  location: string;
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  icon: string;
}

export interface NewsArticle {
  title: string;
  description: string;
  url: string;
  source: string;
  publishedAt: string;
  urlToImage?: string;
}

export interface CalculatorResult {
  expression: string;
  result: string;
  steps?: string[];
}

export interface ImageGenerationData {
  prompt: string;
  imageUrl: string;
  isLoading?: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  picture: string;
  accessToken: string;
}